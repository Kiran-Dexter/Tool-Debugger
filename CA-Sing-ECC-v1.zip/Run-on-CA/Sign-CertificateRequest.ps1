<#
.SYNOPSIS
    Signs certificate requests (CSRs) on a Microsoft Enterprise CA.

.DESCRIPTION
    Run this ON the issuing CA, elevated.

    For CSRs generated elsewhere - Linux, nginx, Apache, Java keytool, F5,
    NetScaler, appliances, anything that made its own key pair. The private key
    never leaves the requester, so this script produces no PFX and needs no
    password.

    Flow:
      1. Prerequisite checks, reported as a batch; nothing is submitted if any fail.
      2. Detects the local CA config string and its AD domain.
      3. Lists templates published on this CA and lets you pick one. Warns about
         any template that would overwrite the subject from the CSR.
      4. SINGLE (one CSR file) or BULK (every CSR in a folder).
      5. Parses each CSR and reports its subject, key size, signature algorithm
         and SAN. Flags weak keys, SHA-1 signatures and a missing SAN before
         anything is submitted.
      6. Submits each CSR to the CA with the chosen template.
      7. Verifies the issued certificate actually carries the CSR's subject and
         SAN, because a misconfigured template silently replaces both.
      8. Writes per-request output: DER .cer, PEM .pem, a fullchain PEM for
         nginx/Apache, the CA chain, and an info file - zipped per request.
      9. Summary table plus a CSV log. One failure does not stop the run.

    Compatible with Windows Server 2012, 2012 R2, 2016, 2019, 2022, 2025
    (PowerShell 3.0+, .NET 4.5+).

.PARAMETER Template
    Template CN, to skip the interactive menu.

.PARAMETER CsrPath
    A single CSR file, or a folder containing CSRs. A folder implies bulk mode.

.PARAMETER Filter
    Which extensions count as a CSR in bulk mode.
    Default: *.req, *.csr, *.pem, *.txt, *.p10

.PARAMETER ExportRoot
    Base output folder. Defaults to C:\tmp. Created if missing and tested for
    writability during the prerequisite checks.

.PARAMETER OutputPath
    Exact folder for this run. Defaults to <ExportRoot>\SignedCerts_<timestamp>.

.PARAMETER AddSan
    DNS names to add as a SAN request attribute, for CSRs that carry no SAN of
    their own. This ONLY works if the CA has EDITF_ATTRIBUTESUBJECTALTNAME2
    enabled, which lets any enroller request any name and is widely considered a
    security weakness. The script detects whether the flag is set and refuses
    the option if it is not. Prefer fixing the CSR.

.PARAMETER MinKeyLength
    Smallest acceptable RSA key in the CSR. Default 2048. Applies to RSA only.

.PARAMETER MinEcKeyLength
    Smallest acceptable elliptic-curve key. Default 256, i.e. P-256.

    EC and RSA key sizes are not comparable: a 256-bit EC key is roughly as
    strong as a 3072-bit RSA key, so applying an RSA floor to an EC key rejects
    perfectly good requests. The script detects the algorithm and applies the
    matching floor.

.PARAMETER Strict
    Treat CSR warnings (weak key, SHA-1 signature, missing SAN) as failures.

.PARAMETER NoPrompt
    Ask nothing; use defaults for anything not passed. -Template and -CsrPath
    must then be supplied.

.EXAMPLE
    .\Sign-CertificateRequest.ps1

.EXAMPLE
    .\Sign-CertificateRequest.ps1 -Template WebServer -CsrPath C:\tmp\csr\

.EXAMPLE
    .\Sign-CertificateRequest.ps1 -Template WebServer -CsrPath C:\tmp\web01.req
#>
[CmdletBinding()]
param(
    [string]   $Template,
    [string]   $CsrPath,
    [string[]] $Filter = @('*.req', '*.csr', '*.pem', '*.txt', '*.p10'),
    [string]   $ExportRoot = 'C:\tmp',
    [string]   $OutputPath,
    [string[]] $AddSan,
    [int]      $MinKeyLength = 2048,
    [int]      $MinEcKeyLength = 256,
    [switch]   $Strict,
    [switch]   $NoPrompt
)

$ErrorActionPreference = 'Stop'

$OID_SERVER_AUTH                   = '1.3.6.1.5.5.7.3.1'
$CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT = 0x00000001
$EDITF_ATTRIBUTESUBJECTALTNAME2    = 0x00040000

# ============================================================ helpers

function Write-Banner {
    param([string] $Text)
    Write-Host ''
    Write-Host ('=' * 62) -ForegroundColor DarkCyan
    Write-Host ("  {0}" -f $Text) -ForegroundColor Cyan
    Write-Host ('=' * 62) -ForegroundColor DarkCyan
}

function Write-Step {
    param([string] $Message)
    Write-Host ''
    Write-Host ("--> {0}" -f $Message) -ForegroundColor Yellow
}

function Test-DnsName {
    param([string] $Name)
    if ([string]::IsNullOrWhiteSpace($Name)) { return 'empty' }
    if ($Name.Length -gt 253)                { return 'longer than 253 characters' }
    if ($Name -match '^[.-]|[.-]$')          { return 'starts or ends with a dot or hyphen' }
    if ($Name -match '\.\.')                 { return 'contains an empty label' }
    foreach ($label in ($Name -split '\.')) {
        if ($label.Length -gt 63) { return "label '$label' exceeds 63 characters" }
        if ($label -notmatch '^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?$') { return "label '$label' has invalid characters" }
    }
    return $null
}

function ConvertTo-Pem {
    param($Certificate)
    $b64 = [Convert]::ToBase64String($Certificate.RawData, 'InsertLineBreaks')
    return "-----BEGIN CERTIFICATE-----`r`n$b64`r`n-----END CERTIFICATE-----`r`n"
}

# ============================================================ preflight

Write-Banner 'CA Certificate Request Signing'

$checks   = New-Object System.Collections.ArrayList
$failures = New-Object System.Collections.ArrayList

function Add-Check {
    param([string] $Name, [bool] $Passed, [string] $Detail, [string] $Remedy)
    [void] $checks.Add((New-Object PSObject -Property @{
        Name = $Name; Passed = $Passed; Detail = $Detail; Remedy = $Remedy
    }))
    if (-not $Passed) { [void] $failures.Add($Name) }
}

Write-Step 'Checking prerequisites...'

$identity  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
$isAdmin   = $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
Add-Check -Name 'Elevated session' -Passed $isAdmin -Detail $identity.Name `
          -Remedy 'Right-click the BAT and choose Run as administrator.'

$psOk = $PSVersionTable.PSVersion.Major -ge 3
Add-Check -Name 'PowerShell 3.0+' -Passed $psOk -Detail $PSVersionTable.PSVersion.ToString() `
          -Remedy 'Install Windows Management Framework 4.0 or later.'

$zipOk = $false
try { Add-Type -AssemblyName 'System.IO.Compression.FileSystem' -ErrorAction Stop; $zipOk = $true } catch { }
$zipDetail = 'assembly unavailable'
if ($zipOk) { $zipDetail = 'System.IO.Compression.FileSystem loaded' }
Add-Check -Name '.NET 4.5 zip support' -Passed $zipOk -Detail $zipDetail `
          -Remedy 'Install .NET Framework 4.5 or later.'

foreach ($exe in @('certreq.exe', 'certutil.exe')) {
    $found = $null
    try { $found = (Get-Command $exe -ErrorAction Stop).Source } catch { }
    $exeDetail = 'not found in PATH'
    if ($found) { $exeDetail = $found }
    Add-Check -Name $exe -Passed ([bool] $found) -Detail $exeDetail `
              -Remedy 'Both ship with Windows. A missing one suggests a damaged install or a stripped PATH.'
}

$caRegRoot = 'HKLM:\SYSTEM\CurrentControlSet\Services\CertSvc\Configuration'
$adcsOk    = Test-Path $caRegRoot
$adcsDetail = 'CertSvc configuration key missing'
if ($adcsOk) { $adcsDetail = 'CertSvc configuration key found' }
Add-Check -Name 'ADCS role present' -Passed $adcsOk -Detail $adcsDetail `
          -Remedy 'Run this script on the issuing CA itself, not on a member server.'

$activeCa = $null
if ($adcsOk) {
    $activeCa = (Get-ItemProperty -Path $caRegRoot -Name 'Active' -ErrorAction SilentlyContinue).Active
}
$caDetail = 'could not read the Active value'
if ($activeCa) { $caDetail = $activeCa }
Add-Check -Name 'Active CA name' -Passed ([bool] $activeCa) -Detail $caDetail `
          -Remedy 'The CA role appears installed but unconfigured. Complete the ADCS post-deployment configuration.'

$certSvc = Get-Service -Name CertSvc -ErrorAction SilentlyContinue
$svcOk   = ($certSvc -ne $null -and $certSvc.Status -eq 'Running')
$svcDetail = 'service not found'
if ($certSvc) { $svcDetail = $certSvc.Status.ToString() }
Add-Check -Name 'CertSvc running' -Passed $svcOk -Detail $svcDetail `
          -Remedy 'Start the Active Directory Certificate Services service: Start-Service CertSvc'

$computerSystem = $null
$domainOk = $false
try {
    $computerSystem = Get-WmiObject -Class Win32_ComputerSystem -ErrorAction Stop
    $domainOk = ($computerSystem.PartOfDomain -eq $true)
} catch { }
$domDetail = 'could not query Win32_ComputerSystem'
if ($computerSystem) { $domDetail = $computerSystem.Domain }
Add-Check -Name 'Domain joined' -Passed $domainOk -Detail $domDetail `
          -Remedy 'An Enterprise CA must be domain-joined to resolve templates from AD.'

$adOk = $false
$adDetail = 'not reachable'
try {
    $rootDseProbe = [ADSI]'LDAP://RootDSE'
    $adDetail = [string] $rootDseProbe.configurationNamingContext[0]
    $adOk = [bool] $adDetail
} catch { $adDetail = $_.Exception.Message }
Add-Check -Name 'AD config partition' -Passed $adOk -Detail $adDetail `
          -Remedy 'Template validation needs LDAP to a domain controller. Check DNS and that a DC is reachable.'

$ExportRoot = $ExportRoot.TrimEnd('\')
$exportOk = $false
$exportDetail = $ExportRoot
try {
    if (-not (Test-Path -LiteralPath $ExportRoot)) {
        $null = New-Item -Path $ExportRoot -ItemType Directory -Force -ErrorAction Stop
        $exportDetail = "$ExportRoot (created)"
    }
    $probe = Join-Path $ExportRoot ("wtest_{0}.tmp" -f ([guid]::NewGuid().ToString('N')))
    Set-Content -LiteralPath $probe -Value 'x' -ErrorAction Stop
    Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
    $exportOk = $true
} catch { $exportDetail = "$ExportRoot - $($_.Exception.Message)" }
Add-Check -Name 'Export folder writable' -Passed $exportOk -Detail $exportDetail `
          -Remedy "Create the folder manually or pass -ExportRoot D:\some\other\path"

$tempOk = $false
$tempDetail = $env:TEMP
try {
    $probe = Join-Path $env:TEMP ("wtest_{0}.tmp" -f ([guid]::NewGuid().ToString('N')))
    Set-Content -LiteralPath $probe -Value 'x' -ErrorAction Stop
    Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
    $tempOk = $true
} catch { $tempDetail = "$env:TEMP - $($_.Exception.Message)" }
Add-Check -Name 'TEMP writable' -Passed $tempOk -Detail $tempDetail `
          -Remedy 'Submission needs a writable TEMP folder.'

Write-Host ''
foreach ($c in $checks) {
    if ($c.Passed) {
        Write-Host ('  [ OK ] {0,-24} {1}' -f $c.Name, $c.Detail) -ForegroundColor Green
    } else {
        Write-Host ('  [FAIL] {0,-24} {1}' -f $c.Name, $c.Detail) -ForegroundColor Red
    }
}

if ($failures.Count -gt 0) {
    Write-Host ''
    Write-Host ("{0} prerequisite check(s) failed. Nothing has been submitted to the CA." -f $failures.Count) -ForegroundColor Red
    Write-Host ''
    foreach ($c in ($checks | Where-Object { -not $_.Passed })) {
        Write-Host ("  {0}" -f $c.Name) -ForegroundColor Red
        Write-Host ("    {0}" -f $c.Remedy) -ForegroundColor DarkYellow
    }
    Write-Host ''
    exit 3
}

Write-Host ''
Write-Host 'All prerequisites satisfied.' -ForegroundColor Green

$caDomain = $computerSystem.Domain.ToLower()
$caFqdn   = ("{0}.{1}" -f $env:COMPUTERNAME, $caDomain).ToLower()
$caConfig = "$caFqdn\$activeCa"
$interactive = -not $NoPrompt

Write-Host ''
Write-Host ("CA host        : {0}" -f $caFqdn)
Write-Host ("CA name        : {0}" -f $activeCa)
Write-Host ("CA config      : {0}" -f $caConfig)
Write-Host ("Export root    : {0}" -f $ExportRoot)

# Does this CA accept SAN as a request attribute? Needed only for CSRs that
# carry no SAN of their own. The flag is a known security weakness, so the
# script reports its state rather than ever changing it.
$sanAttributeAllowed = $false
try {
    $policyKey = Join-Path $caRegRoot "$activeCa\PolicyModules\CertificateAuthority_MicrosoftDefault.Policy"
    $editFlags = (Get-ItemProperty -Path $policyKey -Name 'EditFlags' -ErrorAction Stop).EditFlags
    $sanAttributeAllowed = [bool] ($editFlags -band $EDITF_ATTRIBUTESUBJECTALTNAME2)
} catch { }

Write-Step 'Pinging the CA...'
$ping = & certutil.exe -config "$caConfig" -ping 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host ($ping -join [Environment]::NewLine) -ForegroundColor DarkGray
    Write-Host ''
    Write-Host 'The CA did not answer. Common causes:' -ForegroundColor Red
    Write-Host '  - CertSvc is running but the CA is in a failed state (check the CA console)' -ForegroundColor DarkYellow
    Write-Host '  - the account running this script lacks Request Certificates permission' -ForegroundColor DarkYellow
    Write-Host '  - RPC is blocked between this session and the CA service' -ForegroundColor DarkYellow
    throw "The CA did not answer a ping on $caConfig."
}
Write-Host 'CA responded.' -ForegroundColor Green

# ============================================================ templates

function Get-PublishedTemplate {
    $raw = & certutil.exe -CATemplates 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host ($raw -join [Environment]::NewLine) -ForegroundColor DarkGray
        throw 'certutil -CATemplates failed. Cannot enumerate templates.'
    }

    $published = @()
    foreach ($line in $raw) {
        if ($line -match '^\s*([^:\s][^:]*):\s*(.+?)\s*$') {
            $cn   = $matches[1].Trim()
            $rest = $matches[2].Trim()
            $display = ($rest -split '\s--\s')[0].Trim()
            if ($cn -eq 'CertUtil' -or $cn -like '*command completed*') { continue }
            $published += New-Object PSObject -Property @{ CN = $cn; DisplayName = $display }
        }
    }
    if ($published.Count -eq 0) { throw 'No certificate templates are published on this CA.' }

    $adTemplates = @{}
    try {
        $rootDse    = [ADSI]'LDAP://RootDSE'
        $configNc   = $rootDse.configurationNamingContext[0]
        $container  = [ADSI] "LDAP://CN=Certificate Templates,CN=Public Key Services,CN=Services,$configNc"
        foreach ($child in $container.Children) { $adTemplates[[string] $child.cn[0]] = $child }
    } catch {
        Write-Warning ("Could not read template definitions from AD: {0}" -f $_.Exception.Message)
        Write-Warning 'Continuing without template validation. The CA may reject requests or replace their subjects.'
    }

    foreach ($t in $published) {
        $nameFlag = $null; $minKey = $null; $schema = $null; $ekus = @(); $validity = $null
        $asymAlg = $null; $csps = @()
        $ad = $adTemplates[$t.CN]
        if ($ad) {
            try { $nameFlag = [int] $ad.'msPKI-Certificate-Name-Flag'[0] }   catch { }
            try { $minKey   = [int] $ad.'msPKI-Minimal-Key-Size'[0] }        catch { }
            try { $schema   = [int] $ad.'msPKI-Template-Schema-Version'[0] } catch { }
            try { $ekus     = @($ad.pKIExtendedKeyUsage) }                   catch { }
            try {
                foreach ($raPolicy in @($ad.'msPKI-RA-Application-Policies')) {
                    if ("$raPolicy" -match 'msPKI-Asymmetric-Algorithm[^`]*`[^`]*`([^`]+)') {
                        $asymAlg = $matches[1]
                    }
                }
            } catch { }
            try { $csps = @($ad.pKIDefaultCSPs) } catch { }
            try {
                $ticks = [BitConverter]::ToInt64($ad.pKIExpirationPeriod[0], 0)
                $validity = [TimeSpan]::FromTicks([Math]::Abs($ticks))
            } catch { }
        }
        Add-Member -InputObject $t -MemberType NoteProperty -Name NameFlag      -Value $nameFlag
        Add-Member -InputObject $t -MemberType NoteProperty -Name MinKeySize    -Value $minKey
        Add-Member -InputObject $t -MemberType NoteProperty -Name SchemaVersion -Value $schema
        Add-Member -InputObject $t -MemberType NoteProperty -Name Ekus          -Value $ekus
        Add-Member -InputObject $t -MemberType NoteProperty -Name Validity      -Value $validity
        Add-Member -InputObject $t -MemberType NoteProperty -Name AsymAlgorithm -Value $asymAlg
        Add-Member -InputObject $t -MemberType NoteProperty -Name Csps          -Value $csps
        Add-Member -InputObject $t -MemberType NoteProperty -Name InAd          -Value ([bool] $ad)
    }
    return ,($published | Sort-Object CN)
}

Write-Step 'Enumerating templates published on this CA...'
$templates = Get-PublishedTemplate
Write-Host ("{0} template(s) published." -f $templates.Count) -ForegroundColor Green

function Show-TemplateMenu {
    param($TemplateList)
    Write-Host ''
    Write-Host ('{0,-4} {1,-34} {2,-24} {3,-6} {4}' -f '#', 'Template CN', 'Display Name', 'MinKey', 'Notes')
    Write-Host ('-' * 110)
    for ($i = 0; $i -lt $TemplateList.Count; $i++) {
        $t = $TemplateList[$i]
        $notes = @()
        if (-not $t.InAd) {
            $notes += 'not read from AD'
        } else {
            # Only the subject flag matters when signing a CSR. Key export is
            # irrelevant: the key stays with the requester.
            if ($t.NameFlag -ne $null -and -not ($t.NameFlag -band $CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT)) {
                $notes += 'subject built by CA'
            }
            if ($t.Ekus.Count -gt 0 -and ($t.Ekus -notcontains $OID_SERVER_AUTH)) {
                $notes += 'no server auth EKU'
            }
            if ($t.Validity) { $notes += ('{0}d' -f [int] $t.Validity.TotalDays) }
        }
        $keyText = '?'
        if ($t.MinKeySize) { $keyText = [string] $t.MinKeySize }
        $noteText = 'OK'
        if ($notes.Count) { $noteText = $notes -join '; ' }
        $colour = 'Gray'
        if ($noteText -match 'subject built by CA|no server auth') { $colour = 'DarkYellow' }
        Write-Host ('{0,-4} {1,-34} {2,-24} {3,-6} {4}' -f `
            ($i + 1),
            $t.CN.Substring(0, [Math]::Min(34, $t.CN.Length)),
            $t.DisplayName.Substring(0, [Math]::Min(24, $t.DisplayName.Length)),
            $keyText, $noteText) -ForegroundColor $colour
    }
    Write-Host ''
}

$selected = $null
if ($Template) {
    $selected = $templates | Where-Object { $_.CN -eq $Template -or $_.DisplayName -eq $Template } | Select-Object -First 1
    if (-not $selected) {
        Show-TemplateMenu -TemplateList $templates
        throw "Template '$Template' is not published on this CA. Pick one of the names above."
    }
} elseif ($NoPrompt) {
    Show-TemplateMenu -TemplateList $templates
    throw 'With -NoPrompt you must pass -Template. Pick one of the names above.'
} else {
    Show-TemplateMenu -TemplateList $templates
    while (-not $selected) {
        $answer = Read-Host ("Select template number (1-{0}), or Q to quit" -f $templates.Count)
        if ($answer -match '^[Qq]') { Write-Host 'Cancelled.'; exit 2 }
        $index = 0
        if ([int]::TryParse($answer, [ref] $index) -and $index -ge 1 -and $index -le $templates.Count) {
            $selected = $templates[$index - 1]
        } else {
            Write-Host 'Not a valid selection.' -ForegroundColor Red
        }
    }
}

Write-Host ''
Write-Host ("Template       : {0}  ({1})" -f $selected.CN, $selected.DisplayName) -ForegroundColor Green

if ($selected.InAd -and $selected.NameFlag -ne $null -and
    -not ($selected.NameFlag -band $CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT)) {
    Write-Host ''
    Write-Warning 'This template does not allow the requester to supply the subject.'
    Write-Warning 'The CA will DISCARD the subject and SAN in every CSR and substitute the AD'
    Write-Warning 'object of the account running this script. certreq still reports success, so'
    Write-Warning 'the result looks fine until you open the certificate.'
    Write-Warning ''
    Write-Warning 'Fix: duplicate the template, Subject Name tab > "Supply in the request",'
    Write-Warning 'then publish the duplicate (Certificate Templates > New > Template to Issue).'
    if ($NoPrompt) { throw 'Refusing to sign with a template that overwrites the subject.' }
    Write-Host ''
    $override = Read-Host 'Type PROCEED to sign anyway, anything else to abort'
    if ($override -ne 'PROCEED') { Write-Host 'Aborted.'; exit 2 }
}

if ($selected.InAd -and $selected.Ekus.Count -gt 0 -and ($selected.Ekus -notcontains $OID_SERVER_AUTH)) {
    Write-Warning 'This template has no Server Authentication EKU. The certificates will not be accepted for TLS.'
}

# ============================================================ CSR discovery

function Get-CsrInfo {
    <#
        Parses a CSR with certutil, which prints the same fields on every
        Windows version from 2012 onward. The .NET CSR parser does not exist
        before .NET 5, so text parsing is the portable option here.
    #>
    param([string] $Path, [int] $MinKey, [int] $MinEcKey)

    $info = New-Object PSObject -Property @{
        Path       = $Path
        FileName   = [System.IO.Path]::GetFileName($Path)
        BaseName   = [System.IO.Path]::GetFileNameWithoutExtension($Path)
        Subject    = ''
        CommonName = ''
        KeyLength  = 0
        KeyAlgorithm = ''
        KeyFamily    = ''
        Curve        = ''
        SigAlgorithm = ''
        SanDns     = @()
        SanIp      = @()
        Problems   = @()
        Warnings   = @()
        Parsed     = $false
    }

    $out = & certutil.exe -dump "$Path" 2>&1
    $text = ($out | Out-String)

    if ($LASTEXITCODE -ne 0) {
        $info.Problems += ("certutil could not read this file: " + (($out | Where-Object { $_ -match '\S' }) -join ' | '))
        return $info
    }

    if ($text -notmatch 'PKCS10|Certificate Request|CERTIFICATE REQUEST') {
        if ($text -match 'X509 Certificate:') {
            $info.Problems += 'this is an issued certificate, not a certificate request'
        } else {
            $info.Problems += 'not recognised as a PKCS#10 certificate request'
        }
        return $info
    }

    $lines = $text -split "`r?`n"

    # ---- subject: either inline after the colon, or indented on following lines
    $rdns = @()
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '^\s*Subject:\s*(.*)$') {
            $inline = $matches[1].Trim()
            if ($inline -ne '') { $rdns += $inline }
            for ($j = $i + 1; $j -lt $lines.Count; $j++) {
                if ($lines[$j] -match '^\s+([A-Za-z]+)=(.+)$') {
                    $rdns += ($matches[1] + '=' + $matches[2].Trim())
                } elseif ($lines[$j] -match '^\s*$') {
                    continue
                } else {
                    break
                }
            }
            break
        }
    }
    $info.Subject = ($rdns -join ', ')
    foreach ($rdn in $rdns) {
        if ($rdn -match '^\s*CN=(.+)$') { $info.CommonName = $matches[1].Trim(); break }
    }

    # ---- key
    if ($text -match 'Public Key Length:\s*(\d+)\s*bits') { $info.KeyLength = [int] $matches[1] }

    # The public key OID is what actually identifies the family. certutil's
    # friendly name varies by OS version (ECC, ECDSA, id-ecPublicKey), so match
    # the OID first and fall back to the name.
    $keyOid = $null
    if ($text -match 'Public Key Algorithm:[\s\S]{0,400}?Algorithm ObjectId:\s*([\d\.]+)\s*(\S*)') {
        $keyOid = $matches[1]
        $info.KeyAlgorithm = $matches[2]
    }

    if ($keyOid -eq '1.2.840.10045.2.1' -or $info.KeyAlgorithm -match 'ECC|ECDSA|ecPublicKey') {
        $info.KeyFamily = 'EC'
        if (-not $info.KeyAlgorithm) { $info.KeyAlgorithm = 'ECC' }
    } elseif ($keyOid -eq '1.2.840.113549.1.1.1' -or $info.KeyAlgorithm -match 'RSA') {
        $info.KeyFamily = 'RSA'
        if (-not $info.KeyAlgorithm) { $info.KeyAlgorithm = 'RSA' }
    } elseif ($keyOid -eq '1.2.840.10040.4.1' -or $info.KeyAlgorithm -match 'DSA') {
        $info.KeyFamily = 'DSA'
    } else {
        # No usable name or OID. Infer from the size: no real RSA key is this
        # small, so a sub-512-bit key is an EC key whose label we missed.
        if ($info.KeyLength -gt 0 -and $info.KeyLength -le 521) { $info.KeyFamily = 'EC' }
        else { $info.KeyFamily = 'RSA' }
    }

    if ($info.KeyFamily -eq 'EC') {
        # Named curve, by OID or by certutil's own label.
        $curveMap = @{
            '1.2.840.10045.3.1.7' = 'P-256 (prime256v1)'
            '1.3.132.0.34'        = 'P-384 (secp384r1)'
            '1.3.132.0.35'        = 'P-521 (secp521r1)'
            '1.3.132.0.10'        = 'secp256k1'
        }
        foreach ($oid in $curveMap.Keys) {
            if ($text -match [regex]::Escape($oid)) { $info.Curve = $curveMap[$oid]; break }
        }
        if (-not $info.Curve -and $text -match '(ECDSA_P(?:256|384|521)|nistP(?:256|384|521))') {
            $info.Curve = $matches[1]
        }
        if (-not $info.Curve -and $info.KeyLength -gt 0) {
            $info.Curve = ("P-{0}" -f $info.KeyLength)
        }
    }

    # ---- signature algorithm: the one under "Signature Algorithm:"
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '^\s*Signature Algorithm:') {
            for ($j = $i; $j -lt [Math]::Min($i + 6, $lines.Count); $j++) {
                if ($lines[$j] -match 'Algorithm ObjectId:\s*[\d\.]+\s+(\S+)') {
                    $info.SigAlgorithm = $matches[1]; break
                }
            }
            if ($info.SigAlgorithm) { break }
        }
    }

    # ---- SAN
    $dns = @(); $ips = @()
    foreach ($line in $lines) {
        if ($line -match 'DNS Name=\s*(\S+)')    { $dns += $matches[1].Trim().ToLower() }
        elseif ($line -match 'IP Address=\s*(\S+)') { $ips += $matches[1].Trim() }
    }
    $info.SanDns = @($dns | Select-Object -Unique)
    $info.SanIp  = @($ips | Select-Object -Unique)

    # ---- validation
    if (-not $info.CommonName) {
        $info.Problems += 'the CSR has no Common Name'
    } else {
        $cnProblem = Test-DnsName -Name $info.CommonName
        if ($cnProblem -and $info.CommonName -notmatch '\s') {
            $info.Warnings += ("CN '{0}' is not a valid DNS name ({1})" -f $info.CommonName, $cnProblem)
        }
    }

    if ($info.KeyLength -eq 0) {
        $info.Warnings += 'could not determine the key length'
    } elseif ($info.KeyFamily -eq 'EC') {
        if ($info.KeyLength -lt $MinEcKey) {
            $info.Problems += ("EC key is {0} bits, below the {1}-bit EC minimum" -f $info.KeyLength, $MinEcKey)
        }
    } elseif ($info.KeyFamily -eq 'DSA') {
        $info.Problems += 'DSA keys are not usable for TLS; have the requester generate an RSA or EC key'
    } elseif ($info.KeyLength -lt $MinKey) {
        $info.Problems += ("RSA key is {0} bits, below the {1}-bit RSA minimum" -f $info.KeyLength, $MinKey)
    }

    if ($info.SigAlgorithm -match 'md5|sha1') {
        $info.Warnings += ("CSR is signed with {0}; the issued certificate will use the CA's own hash, but a SHA-1 CSR usually means old tooling" -f $info.SigAlgorithm)
    }

    if ($info.SanDns.Count -eq 0 -and $info.SanIp.Count -eq 0) {
        $info.Warnings += 'the CSR contains no Subject Alternative Name; browsers and current clients reject certificates without one'
    }

    $info.Parsed = $true
    return $info
}

$mode = $null
if ($CsrPath) {
    $CsrPath = $CsrPath.Trim().Trim('"').Trim("'")
    if (Test-Path -LiteralPath $CsrPath -PathType Container) { $mode = 'BULK' }
    elseif (Test-Path -LiteralPath $CsrPath -PathType Leaf)  { $mode = 'SINGLE' }
    else { throw "CSR path not found: $CsrPath" }
}

if (-not $mode -and $NoPrompt) {
    throw 'With -NoPrompt you must pass -CsrPath (a file or a folder).'
}

if (-not $mode) {
    Write-Host ''
    Write-Host 'What do you want to sign?'
    Write-Host '  [1] SINGLE - one CSR file'
    Write-Host '  [2] BULK   - every CSR in a folder'
    Write-Host ''
    while (-not $mode) {
        $answer = Read-Host 'Select 1 or 2, or Q to quit'
        if ($answer -match '^[Qq]') { Write-Host 'Cancelled.'; exit 2 }
        if ($answer -eq '1') { $mode = 'SINGLE' }
        elseif ($answer -eq '2') { $mode = 'BULK' }
        else { Write-Host 'Not a valid selection.' -ForegroundColor Red }
    }

    while (-not $CsrPath) {
        $prompt = 'Full path to the CSR file'
        if ($mode -eq 'BULK') { $prompt = 'Full path to the folder containing the CSRs' }
        $answer = (Read-Host $prompt).Trim().Trim('"').Trim("'")
        if ($answer -eq '') { continue }
        if ($mode -eq 'BULK') {
            if (Test-Path -LiteralPath $answer -PathType Container) { $CsrPath = $answer }
            else { Write-Host 'Not a folder that exists.' -ForegroundColor Red }
        } else {
            if (Test-Path -LiteralPath $answer -PathType Leaf) { $CsrPath = $answer }
            else { Write-Host 'Not a file that exists.' -ForegroundColor Red }
        }
    }
}

$CsrPath = (Resolve-Path -LiteralPath $CsrPath).ProviderPath

$csrFiles = @()
if ($mode -eq 'SINGLE') {
    $csrFiles = @($CsrPath)
} else {
    foreach ($pattern in $Filter) {
        $found = Get-ChildItem -LiteralPath $CsrPath -Filter $pattern -File -ErrorAction SilentlyContinue
        foreach ($f in $found) { if ($csrFiles -notcontains $f.FullName) { $csrFiles += $f.FullName } }
    }
    $csrFiles = @($csrFiles | Sort-Object)
    Write-Host ''
    Write-Host ("{0} candidate file(s) found in {1}" -f $csrFiles.Count, $CsrPath)
}

if ($csrFiles.Count -eq 0) {
    throw "No CSR files found. Looked for: $($Filter -join ', ')"
}

Write-Step 'Parsing certificate requests...'

$requests = @()
$badRequests = @()
foreach ($file in $csrFiles) {
    $info = Get-CsrInfo -Path $file -MinKey $MinKeyLength -MinEcKey $MinEcKeyLength
    if ($info.Problems.Count -gt 0 -and -not $info.Parsed) { $badRequests += $info; continue }
    if ($info.Problems.Count -gt 0) { $badRequests += $info; continue }
    $requests += $info
}

if ($badRequests.Count -gt 0) {
    Write-Host ''
    Write-Host ("{0} file(s) cannot be signed:" -f $badRequests.Count) -ForegroundColor Red
    foreach ($b in $badRequests) {
        Write-Host ("  {0,-34} {1}" -f $b.FileName, ($b.Problems -join '; ')) -ForegroundColor Red
    }
}

if ($requests.Count -eq 0) { throw 'No valid certificate requests to sign.' }

Write-Host ''
Write-Host ("{0} request(s) ready:" -f $requests.Count) -ForegroundColor Green
Write-Host ''
Write-Host ('{0,-26} {1,-32} {2,-14} {3}' -f 'File', 'Common Name', 'Key', 'SAN')
Write-Host ('-' * 110)
foreach ($r in $requests) {
    $sanAll = @($r.SanDns) + @($r.SanIp)
    $sanText = '(none)'
    if ($sanAll.Count -gt 0) { $sanText = $sanAll -join ', ' }
    if ($sanText.Length -gt 36) { $sanText = $sanText.Substring(0, 33) + '...' }
    $keyText = ("{0} {1}" -f $r.KeyFamily, $r.KeyLength)
    if ($r.KeyFamily -eq 'EC' -and $r.Curve) { $keyText = ("EC {0}" -f $r.Curve.Split(' ')[0]) }
    Write-Host ('{0,-26} {1,-32} {2,-14} {3}' -f `
        $r.FileName.Substring(0, [Math]::Min(26, $r.FileName.Length)),
        $r.CommonName.Substring(0, [Math]::Min(32, $r.CommonName.Length)),
        $keyText, $sanText)
    foreach ($w in $r.Warnings) { Write-Host ("    ! {0}" -f $w) -ForegroundColor DarkYellow }
}

$warnCount = 0
foreach ($r in $requests) { $warnCount += $r.Warnings.Count }
if ($warnCount -gt 0 -and $Strict) {
    throw "$warnCount warning(s) and -Strict was specified. Nothing was submitted."
}

# ---- template minimum key size, checked per request
# ---- will this template actually accept an EC request? -------------------------

$ecRequests = @($requests | Where-Object { $_.KeyFamily -eq 'EC' })

if ($ecRequests.Count -gt 0) {
    Write-Host ''
    Write-Host ("{0} request(s) use elliptic-curve keys. Checking template compatibility..." -f $ecRequests.Count) -ForegroundColor Cyan

    $ecBlockers = @()
    $ecNotes    = @()

    if (-not $selected.InAd) {
        $ecNotes += 'the template could not be read from AD, so this cannot be checked up front'
    } else {
        # Schema v1 and v2 predate CNG. Their crypto settings are legacy-CSP
        # only, and the CA rejects an EC public key against them.
        if ($selected.SchemaVersion -ne $null -and $selected.SchemaVersion -le 2) {
            $ecBlockers += ("template schema is v{0}; v1 and v2 templates are legacy-CSP and cannot carry EC keys. An ECC template must be schema v3 or later (Windows Server 2008 or newer on the Compatibility tab)." -f $selected.SchemaVersion)
        }

        # ADCS compares the raw bit count, so an RSA-sized minimum denies EC.
        $smallestEc = ($ecRequests | Sort-Object KeyLength | Select-Object -First 1).KeyLength
        if ($selected.MinKeySize -and $smallestEc -lt $selected.MinKeySize) {
            $ecBlockers += ("template minimum key size is {0}; the smallest EC key here is {1} bits. ADCS compares the raw number, so this is denied even though the key is strong." -f $selected.MinKeySize, $smallestEc)
        }

        if ($selected.AsymAlgorithm) {
            Write-Host ("  Template algorithm : {0}" -f $selected.AsymAlgorithm)
            if ($selected.AsymAlgorithm -match 'RSA') {
                $ecNotes += ("the template specifies {0}; that setting mainly steers clients that generate their own keys, but on some builds the CA validates it too" -f $selected.AsymAlgorithm)
            }
        }
        if ($selected.Csps.Count -gt 0) {
            $cspText = ($selected.Csps -join '; ')
            if ($cspText.Length -gt 90) { $cspText = $cspText.Substring(0, 87) + '...' }
            Write-Host ("  Template providers : {0}" -f $cspText)
        }
    }

    Write-Host ("  Template schema    : v{0}" -f $selected.SchemaVersion)
    Write-Host ("  Template min key   : {0}" -f $selected.MinKeySize)
    foreach ($r in $ecRequests) {
        Write-Host ("  Request            : {0}  {1}, {2} bits" -f $r.FileName, $r.Curve, $r.KeyLength)
    }

    if ($ecBlockers.Count -gt 0) {
        Write-Host ''
        Write-Host '  This template will NOT sign these EC requests:' -ForegroundColor Red
        foreach ($b in $ecBlockers) { Write-Host ("    - {0}" -f $b) -ForegroundColor Red }
        Write-Host ''
        Write-Host '  Two ways forward:' -ForegroundColor Yellow
        Write-Host '' -ForegroundColor Yellow
        Write-Host '  1. Make an ECC template (do this once, then reuse it):' -ForegroundColor Yellow
        Write-Host '       CA console > Certificate Templates > Manage' -ForegroundColor Yellow
        Write-Host '       Duplicate a Web Server template' -ForegroundColor Yellow
        Write-Host '       Compatibility tab : CA and recipient both Windows Server 2012 or later' -ForegroundColor Yellow
        Write-Host '       Cryptography tab  : Provider Category = Key Storage Provider' -ForegroundColor Yellow
        Write-Host '                           Algorithm name    = ECDSA_P256' -ForegroundColor Yellow
        Write-Host '                           Minimum key size  = 256' -ForegroundColor Yellow
        Write-Host '       Subject Name tab  : Supply in the request' -ForegroundColor Yellow
        Write-Host '       Then publish it: Certificate Templates > New > Template to Issue' -ForegroundColor Yellow
        Write-Host '' -ForegroundColor Yellow
        Write-Host '  2. Or have the requester send an RSA CSR instead:' -ForegroundColor Yellow
        Write-Host '       openssl req -new -newkey rsa:2048 -nodes -keyout host.key -out host.csr' -ForegroundColor Yellow
        Write-Host ''
        Write-Host '  Note: the CA''s OWN key does not need to be ECC. An RSA CA signs EC requests' -ForegroundColor DarkGray
        Write-Host '  perfectly well - the issued certificate carries the EC public key and an RSA' -ForegroundColor DarkGray
        Write-Host '  signature. Only the template matters here.' -ForegroundColor DarkGray

        if ($NoPrompt) { throw 'The selected template cannot sign these EC requests.' }
        Write-Host ''
        $ecOverride = Read-Host '  Submit anyway and let the CA decide? [y/N]'
        if ($ecOverride -notmatch '^[Yy]') { Write-Host 'Cancelled.'; exit 2 }
    } else {
        Write-Host '  Template looks compatible with these EC requests.' -ForegroundColor Green
        foreach ($n in $ecNotes) { Write-Host ("    note: {0}" -f $n) -ForegroundColor DarkYellow }
    }
}

if ($selected.MinKeySize) {
    # ADCS compares the raw bit count, so an EC request against a template whose
    # minimum was set for RSA is denied even though the key is strong. Flag that
    # as a template mismatch rather than calling the key weak.
    $rsaTooSmall = @($requests | Where-Object {
        $_.KeyFamily -ne 'EC' -and $_.KeyLength -gt 0 -and $_.KeyLength -lt $selected.MinKeySize
    })

    if ($rsaTooSmall.Count -gt 0) {
        Write-Host ''
        Write-Warning ("The template requires at least {0}-bit keys. These will be denied by the CA:" -f $selected.MinKeySize)
        foreach ($t in $rsaTooSmall) { Write-Warning ("  {0} ({1} {2} bits)" -f $t.FileName, $t.KeyFamily, $t.KeyLength) }
    }

}

# ---- SAN injection for CSRs that have none
$sanAttribute = $null
$noSan = @($requests | Where-Object { $_.SanDns.Count -eq 0 -and $_.SanIp.Count -eq 0 })

if ($AddSan) {
    if (-not $sanAttributeAllowed) {
        throw @'
-AddSan was given but this CA does not accept SAN as a request attribute
(EDITF_ATTRIBUTESUBJECTALTNAME2 is not set). Enabling that flag lets any
enroller request any name and is a recognised security weakness, so this script
will not set it. Have the requester regenerate the CSR with the SAN included.
'@
    }
    $names = @()
    foreach ($entry in $AddSan) {
        foreach ($piece in ($entry -split '[,;\s]+')) {
            $v = $piece.Trim().ToLower()
            if ($v -eq '') { continue }
            $problem = Test-DnsName -Name $v
            if ($problem) { throw "-AddSan value '$piece' is not a valid DNS name: $problem" }
            if ($names -notcontains $v) { $names += $v }
        }
    }
    if ($names.Count -gt 0) {
        $sanAttribute = 'san:' + (($names | ForEach-Object { "dns=$_" }) -join '&')
        Write-Host ''
        Write-Host ("SAN attribute  : {0}" -f ($names -join ', ')) -ForegroundColor Cyan
        Write-Host '                 applied to EVERY request in this run' -ForegroundColor DarkYellow
    }
}

if ($noSan.Count -gt 0 -and -not $sanAttribute) {
    Write-Host ''
    Write-Host ("{0} request(s) carry no SAN." -f $noSan.Count) -ForegroundColor DarkYellow
    if ($sanAttributeAllowed) {
        Write-Host 'This CA does accept SAN as a request attribute, so a name could be added at' -ForegroundColor DarkYellow
        Write-Host 'signing time with -AddSan. That attribute applies to every request in the run,' -ForegroundColor DarkYellow
        Write-Host 'so it is only sensible for a single CSR.' -ForegroundColor DarkYellow
    } else {
        Write-Host 'The right fix is a new CSR with the SAN included; this CA does not accept SAN' -ForegroundColor DarkYellow
        Write-Host 'as a request attribute, and enabling that is a security weakness.' -ForegroundColor DarkYellow
    }
}

# ============================================================ output

if (-not $OutputPath) {
    $OutputPath = Join-Path $ExportRoot ("SignedCerts_{0:yyyyMMdd_HHmmss}" -f (Get-Date))
}
try { $null = New-Item -Path $OutputPath -ItemType Directory -Force }
catch { throw "Could not create the output folder '$OutputPath': $($_.Exception.Message)" }
$OutputPath = (Resolve-Path -LiteralPath $OutputPath).ProviderPath

$workRoot = Join-Path $env:TEMP ("casign_{0}" -f ([guid]::NewGuid().ToString('N')))
$null = New-Item -Path $workRoot -ItemType Directory -Force

Write-Step 'Exporting the CA chain...'
$chainDir = Join-Path $workRoot 'chain'
$null = New-Item -Path $chainDir -ItemType Directory -Force
$chainP7b = Join-Path $chainDir 'ca-chain.p7b'
$chainPem = Join-Path $chainDir 'ca-chain.pem'
$rootPem  = Join-Path $chainDir 'ca-root.pem'
$intPem   = Join-Path $chainDir 'ca-intermediate.pem'
$chainCerts = @()
$chainIntermediates = @()
$chainRoots = @()

try {
    $caChainOut = & certutil.exe -config "$caConfig" -ca.chain "$chainP7b" 2>&1
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $chainP7b)) { throw ($caChainOut -join ' ') }

    $chainCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
    $chainCollection.Import($chainP7b)
    foreach ($c in $chainCollection) { $chainCerts += $c }

    foreach ($c in $chainCerts) {
        if ($c.Subject -eq $c.Issuer) { $chainRoots += $c } else { $chainIntermediates += $c }
    }

    $chainText = ''
    foreach ($c in $chainIntermediates) { $chainText += (ConvertTo-Pem $c) }
    foreach ($c in $chainRoots)         { $chainText += (ConvertTo-Pem $c) }
    Set-Content -LiteralPath $chainPem -Value $chainText -Encoding ASCII

    if ($chainRoots.Count -gt 0) {
        $t = ''
        foreach ($c in $chainRoots) { $t += (ConvertTo-Pem $c) }
        Set-Content -LiteralPath $rootPem -Value $t -Encoding ASCII
    }
    if ($chainIntermediates.Count -gt 0) {
        $t = ''
        foreach ($c in $chainIntermediates) { $t += (ConvertTo-Pem $c) }
        Set-Content -LiteralPath $intPem -Value $t -Encoding ASCII
    }

    foreach ($c in $chainIntermediates) { Write-Host ("  intermediate : {0}" -f $c.Subject) }
    foreach ($c in $chainRoots)         { Write-Host ("  root         : {0}" -f $c.Subject) }
} catch {
    Write-Warning ("Could not export the CA chain: {0}" -f $_.Exception.Message)
    Write-Warning 'Signed certificates will still be written; the chain files will be missing from the output.'
}

# ---- run summary
Write-Host ''
Write-Host ('-' * 62)
Write-Host ("  Template : {0}" -f $selected.CN)
Write-Host ("  Requests : {0}" -f $requests.Count)
Write-Host ("  Output   : {0}" -f $OutputPath)
if ($sanAttribute) { Write-Host ("  SAN attr : {0}" -f $sanAttribute) }
Write-Host ('-' * 62)

if ($NoPrompt) {
    Write-Host ''
    Write-Host ("-NoPrompt: signing {0} request(s)." -f $requests.Count) -ForegroundColor Cyan
} else {
    Write-Host ''
    $confirm = Read-Host ("Sign {0} request(s)? [y/N]" -f $requests.Count)
    if ($confirm -notmatch '^[Yy]') { Write-Host 'Cancelled.'; exit 2 }
}

# ============================================================ signing

function Invoke-CsrSigning {
    param(
        [PSObject] $Request,
        [string]   $TemplateCn,
        [string]   $CaConfigString,
        [string]   $SanAttrib,
        [string]   $WorkDirectory,
        [string]   $Destination,
        [string]   $ChainDirectory,
        [object[]] $Intermediates,
        [object[]] $Roots
    )

    $result = New-Object PSObject -Property @{
        File       = $Request.FileName
        CommonName = $Request.CommonName
        Status     = 'Failed'
        Serial     = ''
        Thumbprint = ''
        NotAfter   = ''
        RequestId  = ''
        ZipFile    = ''
        Detail     = ''
        SubjectMismatch = $false
    }

    # A CSR's base name can collide or contain characters that are awkward in a
    # file name, so derive the output name from the CN where there is one.
    $stem = $Request.BaseName
    if ($Request.CommonName -and $Request.CommonName -notmatch '[\\/:*?"<>|]') {
        $stem = $Request.CommonName.ToLower()
    }
    $stem = ($stem -replace '[\\/:*?"<>|]', '_')

    $reqDir = Join-Path $WorkDirectory ([guid]::NewGuid().ToString('N'))
    $null = New-Item -Path $reqDir -ItemType Directory -Force
    $cerFile = Join-Path $reqDir ("{0}.cer" -f $stem)

    try {
        # ---- 1. submit
        # The template is passed as a request attribute: an existing CSR cannot
        # carry an INF's [RequestAttributes] section.
        $attrib = "CertificateTemplate:$TemplateCn"
        if ($SanAttrib) { $attrib = $attrib + '\n' + $SanAttrib }

        $out = & certreq.exe -submit -q -config "$CaConfigString" -attrib "$attrib" "$($Request.Path)" "$cerFile" 2>&1
        $outText = (($out | Where-Object { $_ -match '\S' }) -join ' | ')

        if ($outText -match 'RequestId:\s*(\d+)') { $result.RequestId = $matches[1] }

        if (-not (Test-Path -LiteralPath $cerFile)) {
            if ($outText -match 'Taken Under Submission|pending') {
                $result.Status = 'Pending'
                $result.Detail = "Request $($result.RequestId) awaits manager approval. Approve it in the CA console, then: certreq -retrieve -config `"$CaConfigString`" $($result.RequestId) $stem.cer"
                return $result
            }
            if ($outText -match 'Denied|denied') {
                throw ("the CA denied the request: " + $outText)
            }
            throw ("submission produced no certificate: " + $outText)
        }

        # ---- 2. load the issued certificate
        $leaf = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
        $leaf.Import($cerFile)

        $result.Thumbprint = $leaf.Thumbprint.ToUpper()
        $result.Serial     = $leaf.SerialNumber
        $result.NotAfter   = $leaf.NotAfter.ToString('yyyy-MM-dd')

        # ---- 3. did the CA honour the CSR's subject and SAN?
        $issuedCn = $null
        if ($leaf.Subject -match '(?:^|,\s*)CN=([^,]+)') { $issuedCn = $matches[1].Trim() }

        $issuedDns = @()
        foreach ($ext in $leaf.Extensions) {
            if ($ext.Oid.Value -eq '2.5.29.17') {
                foreach ($line in ($ext.Format($true) -split "`r?`n")) {
                    if ($line -match 'DNS Name=([^,\s]+)') { $issuedDns += $matches[1].Trim().ToLower() }
                }
            }
        }

        $mismatch = @()
        if (-not $leaf.Subject -or $leaf.Subject.Trim() -eq '') {
            $mismatch += 'the issued certificate has an EMPTY subject'
        } elseif (-not $issuedCn) {
            $mismatch += ("the issued subject has no CN (got '{0}')" -f $leaf.Subject)
        } elseif ($Request.CommonName -and $issuedCn.ToLower() -ne $Request.CommonName.ToLower()) {
            $mismatch += ("the issued CN is '{0}' but the CSR asked for '{1}'" -f $issuedCn, $Request.CommonName)
        }

        $lostSan = @()
        foreach ($want in $Request.SanDns) {
            if ($issuedDns -notcontains $want) { $lostSan += $want }
        }
        if ($lostSan.Count -gt 0) {
            $mismatch += ("the CA dropped these SAN entries: {0}" -f ($lostSan -join ', '))
        }

        if ($mismatch.Count -gt 0) {
            $result.SubjectMismatch = $true
            throw ("the CA did not honour the CSR: {0}. Serial {1} was issued but does not match the request; revoke it with: certutil -revoke {1} 4" -f ($mismatch -join '; '), $leaf.SerialNumber)
        }

        # ---- 4. stage the output
        $stage = Join-Path $reqDir 'stage'
        $null = New-Item -Path $stage -ItemType Directory -Force

        Copy-Item -LiteralPath $cerFile -Destination (Join-Path $stage ("{0}.cer" -f $stem)) -Force

        $leafPem = ConvertTo-Pem $leaf
        Set-Content -LiteralPath (Join-Path $stage ("{0}.pem" -f $stem)) -Value $leafPem -Encoding ASCII

        # fullchain: leaf, then intermediates, then root. What nginx and Apache want.
        $fullchain = $leafPem
        foreach ($c in @($Intermediates)) { $fullchain += (ConvertTo-Pem $c) }
        foreach ($c in @($Roots))         { $fullchain += (ConvertTo-Pem $c) }
        Set-Content -LiteralPath (Join-Path $stage ("{0}-fullchain.pem" -f $stem)) -Value $fullchain -Encoding ASCII

        if ($ChainDirectory -and (Test-Path -LiteralPath $ChainDirectory)) {
            Get-ChildItem -LiteralPath $ChainDirectory -File |
                Where-Object { $_.Extension -eq '.pem' -or $_.Extension -eq '.p7b' } |
                ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $stage $_.Name) -Force }
        }

        # also keep the original CSR alongside, for the record
        Copy-Item -LiteralPath $Request.Path -Destination (Join-Path $stage $Request.FileName) -Force

        $sanAll = @($Request.SanDns) + @($Request.SanIp)
        $sanText = '(none in the CSR)'
        if ($sanAll.Count -gt 0) { $sanText = $sanAll -join ', ' }

        $info = @"
Signed certificate
==================

Common Name      : $($Request.CommonName)
Subject          : $($leaf.Subject)
Issuer           : $($leaf.Issuer)
Serial           : $($leaf.SerialNumber)
Thumbprint       : $($result.Thumbprint)
Valid from       : $($leaf.NotBefore)
Expires          : $($leaf.NotAfter)
Template         : $TemplateCn
Signed by        : $CaConfigString
Signed on        : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')

From the request
----------------
CSR file         : $($Request.FileName)
Key              : $($Request.KeyFamily) $($Request.KeyLength) bits $($Request.Curve)
CSR signature    : $($Request.SigAlgorithm)
SAN requested    : $sanText

Verified         : the issued CN and SAN match the request

Files
-----
  $stem.cer              issued certificate, DER - Windows, IIS
  $stem.pem              issued certificate, PEM - Linux, nginx, Apache
  $stem-fullchain.pem    certificate + chain, PEM - what nginx ssl_certificate wants
  ca-chain.pem           intermediates then root
  ca-root.pem            root CA only - upload this to scanners such as Nessus
  ca-intermediate.pem    issuing CA(s), if the hierarchy has one
  ca-chain.p7b           the chain in PKCS#7, for Windows import
  $($Request.FileName)   the original request, for the record

THE PRIVATE KEY IS NOT HERE. It never left the machine that generated the CSR.
Install these files alongside the key already on that machine.

nginx
-----
  ssl_certificate      /path/$stem-fullchain.pem;
  ssl_certificate_key  /path/your-existing.key;

Apache
------
  SSLCertificateFile       /path/$stem.pem
  SSLCertificateKeyFile    /path/your-existing.key
  SSLCertificateChainFile  /path/ca-chain.pem

IIS - complete the pending request on the server that created it
----------------------------------------------------------------
  certreq -accept $stem.cer
"@
        Set-Content -LiteralPath (Join-Path $stage 'cert-info.txt') -Value $info -Encoding ASCII

        # ---- 5. zip. Nothing secret in here: no private key.
        $zipPath = Join-Path $Destination ("{0}.zip" -f $stem)
        $suffix = 1
        while (Test-Path -LiteralPath $zipPath) {
            $zipPath = Join-Path $Destination ("{0}_{1}.zip" -f $stem, $suffix)
            $suffix++
        }
        [System.IO.Compression.ZipFile]::CreateFromDirectory(
            $stage, $zipPath,
            [System.IO.Compression.CompressionLevel]::Optimal, $false)
        if (-not (Test-Path -LiteralPath $zipPath)) { throw 'ZIP creation produced no file' }

        $result.ZipFile = $zipPath
        $result.Status  = 'Signed'
        return $result
    } catch {
        if ($result.Status -ne 'Pending') { $result.Status = 'Failed' }
        if (-not $result.Detail) { $result.Detail = $_.Exception.Message }
        return $result
    } finally {
        try { Remove-Item -LiteralPath $reqDir -Recurse -Force -ErrorAction SilentlyContinue } catch { }
    }
}

Write-Banner ("Signing {0} request(s)" -f $requests.Count)

$results = New-Object System.Collections.ArrayList
$index = 0

foreach ($request in $requests) {
    $index++
    Write-Host ''
    Write-Host ("[{0}/{1}] {2}  ->  {3}" -f $index, $requests.Count, $request.FileName, $request.CommonName) -ForegroundColor White

    $r = Invoke-CsrSigning -Request $request `
                           -TemplateCn $selected.CN `
                           -CaConfigString $caConfig `
                           -SanAttrib $sanAttribute `
                           -WorkDirectory $workRoot `
                           -Destination $OutputPath `
                           -ChainDirectory $chainDir `
                           -Intermediates $chainIntermediates `
                           -Roots $chainRoots

    [void] $results.Add($r)

    if ($r.Status -eq 'Signed') {
        Write-Host ("        OK      serial {0}, expires {1}" -f $r.Serial, $r.NotAfter) -ForegroundColor Green
    } elseif ($r.Status -eq 'Pending') {
        Write-Host ("        PENDING {0}" -f $r.Detail) -ForegroundColor DarkYellow
    } else {
        Write-Host ("        FAILED  {0}" -f $r.Detail) -ForegroundColor Red
    }

    if ($r.SubjectMismatch) {
        Write-Host ''
        Write-Host ('!' * 62) -ForegroundColor Red
        Write-Host '  STOPPING: the CA is replacing what the CSR asked for.' -ForegroundColor Red
        Write-Host '  Every remaining request would come out the same way.' -ForegroundColor Red
        Write-Host ''
        Write-Host ("  Fix template '{0}':" -f $selected.CN) -ForegroundColor Yellow
        Write-Host '    CA console > Certificate Templates > right-click > Properties' -ForegroundColor Yellow
        Write-Host '    Subject Name tab > select "Supply in the request"' -ForegroundColor Yellow
        Write-Host '    (duplicate it first if it is a built-in template)' -ForegroundColor Yellow
        Write-Host ('!' * 62) -ForegroundColor Red

        foreach ($skip in ($requests | Select-Object -Skip $index)) {
            [void] $results.Add((New-Object PSObject -Property @{
                File = $skip.FileName; CommonName = $skip.CommonName; Status = 'Skipped'
                Serial = ''; Thumbprint = ''; NotAfter = ''; RequestId = ''; ZipFile = ''
                SubjectMismatch = $false
                Detail = 'not attempted: the template replaces the requested subject'
            }))
        }
        break
    }
}

# ============================================================ wrap up

try { Remove-Item -LiteralPath $workRoot -Recurse -Force -ErrorAction SilentlyContinue } catch { }

$signed  = @($results | Where-Object { $_.Status -eq 'Signed' })
$pending = @($results | Where-Object { $_.Status -eq 'Pending' })
$failed  = @($results | Where-Object { $_.Status -eq 'Failed' })
$skipped = @($results | Where-Object { $_.Status -eq 'Skipped' })

$csvPath = Join-Path $OutputPath ("signing-log_{0:yyyyMMdd_HHmmss}.csv" -f (Get-Date))
$results | Select-Object File, CommonName, Status, Serial, Thumbprint, NotAfter, RequestId, ZipFile, Detail |
    Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8

Write-Banner 'Summary'
Write-Host ("Signed   : {0}" -f $signed.Count) -ForegroundColor Green
if ($pending.Count)     { Write-Host ("Pending  : {0}" -f $pending.Count) -ForegroundColor DarkYellow }
if ($failed.Count)      { Write-Host ("Failed   : {0}" -f $failed.Count) -ForegroundColor Red }
if ($skipped.Count)     { Write-Host ("Not run  : {0} (stopped after a subject mismatch)" -f $skipped.Count) -ForegroundColor Red }
if ($badRequests.Count) { Write-Host ("Unusable : {0} input file(s)" -f $badRequests.Count) -ForegroundColor DarkYellow }

if ($failed.Count -gt 0) {
    Write-Host ''
    Write-Host 'Failures:' -ForegroundColor Red
    foreach ($f in $failed) { Write-Host ("  {0,-34} {1}" -f $f.File, $f.Detail) -ForegroundColor Red }
}

if ($pending.Count -gt 0) {
    Write-Host ''
    Write-Host 'Awaiting CA manager approval:' -ForegroundColor DarkYellow
    foreach ($p in $pending) { Write-Host ("  {0,-34} request {1}" -f $p.File, $p.RequestId) -ForegroundColor DarkYellow }
}

Write-Host ''
Write-Host ("ZIP files : {0}" -f $OutputPath)
Write-Host ("Log       : {0}" -f $csvPath)
Write-Host ''
Write-Host 'Each ZIP holds the signed certificate in DER and PEM, a fullchain PEM, the CA' -ForegroundColor Cyan
Write-Host 'chain, the original CSR and an info file. No private keys: they never left the' -ForegroundColor Cyan
Write-Host 'requesting machines, so these files are not secret and can be emailed as-is.' -ForegroundColor Cyan

if ($failed.Count -gt 0 -or $skipped.Count -gt 0) { exit 1 }
exit 0
