================================================================================
 RDP / TLS CERTIFICATE TOOLKIT
 Windows Server 2012, 2012 R2, 2016, 2019, 2022, 2025
================================================================================

 IMPORTANT: these scripts have not been executed against a live CA. They are
 written to documented ADCS and certreq behaviour. Do a single-host test run
 before feeding in a bulk list. See "FIRST RUN" below.

--------------------------------------------------------------------------------
 CONTENTS
--------------------------------------------------------------------------------

 Run on the CA - generate keys AND certificates (for Windows hosts)
   Issue-Certificates.bat            launcher - double-click this
   New-BulkHostCertificate.ps1       does the work
   hosts.txt                         sample bulk input file

 Run on the CA - sign CSRs made elsewhere (Linux, nginx, appliances, IIS)
   Sign-Requests.bat                 launcher - double-click, or drag a CSR onto it
   Sign-CertificateRequest.ps1       does the work

 Run on each target server
   Install-RdpCertificate.bat        launcher - double-click this
   Install-RdpCertificate.ps1        does the work

 Run on the requester's machine - turn a signed .cer into a .pfx
   Make-Pfx.bat                      launcher - drag the signed .cer onto it
   Convert-ToPfx.ps1                 does the work

 Both BAT files must stay in the same folder as their matching PS1.
 Extract the whole ZIP; do not move files out individually.

--------------------------------------------------------------------------------
 PART 1 - ISSUE CERTIFICATES (on the CA)
--------------------------------------------------------------------------------

 PREREQUISITES - checked automatically before anything is submitted

   The script runs ten checks and reports all failures at once, with a remedy
   for each. It exits with code 3 and submits nothing if any fail.

     1  Elevated session
     2  PowerShell 3.0 or later
     3  .NET Framework 4.5 or later (for ZIP support)
     4  certreq.exe present
     5  certutil.exe present
     6  ADCS role installed and this machine is the CA
     7  CertSvc service running
     8  Machine is domain-joined
     9  AD configuration partition reachable over LDAP
    10  C:\tmp writable, and TEMP writable

   Not machine-checkable, so confirm manually:
     - Your account has "Request Certificates" on the CA.
     - The template you pick has BOTH of these, or the script will warn:
         * Subject Name  >  Supply in the request
         * Request Handling  >  Allow private key to be exported
       Stock templates usually have neither. Duplicate a Web Server template
       and enable both.

 USAGE

   Interactive (recommended):
     Right-click Issue-Certificates.bat  >  Run as administrator

     It asks for everything in order:
       1  pick a template from a numbered list
       2  SINGLE or BULK
       3  a hostname, or the path to your hosts file
       4  optional subject fields - OU, O, L, S, C (answer n to skip all)
       5  extra SAN name(s) for every host (Enter for none)
       6  add IP addresses to the SAN? (y if scanners target by IP)
       7  include the short NetBIOS name? (default yes)
       7b cryptographic provider - legacy CSP or CNG KSP, auto-detected from
          the template, Enter to accept
       8  the PFX password, twice
       9  a summary, then y to go ahead

     Anything you pass on the command line is not asked for again, so you can
     answer some questions up front and be prompted for the rest.

   Unattended (scheduled tasks):
     Add -NoPrompt. Nothing is asked and defaults apply, so -Template, either
     -HostFile or -ComputerName, and -Password must all be supplied.

   Non-interactive:
     Issue-Certificates.bat -Template WebServerExportable -HostFile C:\tmp\hosts.txt
     Issue-Certificates.bat -ComputerName SRV-APP01
     Issue-Certificates.bat -Template WebServerExportable -ExportRoot D:\certs

   Useful switches:
     -ExportRoot <path>        base output folder          (default C:\tmp)
     -Domain <dns.domain>      suffix for bare hostnames   (default: CA's own)
     -KeyLength 4096           key size                    (default 2048)
     -IncludeShortName:$false  omit the NetBIOS name from the SAN
     -Provider CSP|KSP|Auto    provider family            (default Auto)
     -LegacyCsp                shorthand for -Provider CSP
                               NOTE: ONE dash, not two. --legacy is not valid
                               PowerShell and will be ignored or error.
     -KeepInStore              leave private keys on the CA (not recommended)
     -NoPrompt                 ask nothing; for unattended runs

   Subject fields (all optional, CN is always the host FQDN):
     -OrganizationalUnit IT            OU=   (several allowed: 'IT','Servers')
     -Organization "Example Corp"      O=
     -Locality Singapore               L=
     -State Singapore                  S=
     -Country SG                       C=    two-letter ISO code
     -IncludeIpAddress                 add each host's IPv4 address to the SAN

   Subject Alternative Names:
     Automatic on every certificate:  the FQDN and the short name.
     -IncludeShortName:$false          drop the short name
     -IncludeIpAddress                 add resolved IPv4 address(es)
     -AdditionalSan a,b                add these names to EVERY host
     Per-host extra names go in the hosts file, after the primary name:
         srv-web01, intranet.corp.example.com, web-vip
     The FIRST name on the line becomes the CN; the rest are SAN only.
     A bad alias is reported and dropped; the host is still issued.

   Full example:
     Issue-Certificates.bat -Template RDP-Server -HostFile C:\tmp\hosts.txt -LegacyCsp ^
         -OrganizationalUnit IT -Organization "Example Corp" -Country SG -IncludeIpAddress

 OUTPUT

   C:\tmp\HostCerts_<yyyyMMdd_HHmmss>\
       srv-app01.corp.example.com.zip
       srv-app02.corp.example.com.zip
       ...
       issuance-log_<timestamp>.csv

   Each ZIP contains four files:
       <fqdn>.pfx          certificate + private key + full CA chain,
                           encrypted with the password you typed
       <fqdn>.cer          the issued certificate alone, no private key
       ca-chain.pem        intermediates then root, clean PEM
       ca-root.pem         root CA only (upload this to Nessus)
       ca-intermediate.pem issuing CA(s), if the hierarchy has one
       ca-chain.p7b        the chain in PKCS#7 for Windows import
       cert-info.txt       subject, issuer, serial, thumbprint, validity dates,
                           template used, key length, SAN entries

   SUBJECT VERIFICATION: after the CA signs each certificate the script checks
   the CN and SAN actually match what was requested. If the template is set to
   build the subject from Active Directory, the CA silently replaces them and
   certreq still reports success. The script now catches this, discards the
   certificate, prints the revoke command, and STOPS the run, because every
   remaining host would come out the same.

   The ZIP container itself is NOT encrypted. The PFX inside is. Move the files
   over a trusted channel.

 CERTIFICATE VALIDITY

   The script never requests a lifetime, because an Enterprise CA ignores any
   lifetime asked for in a CSR. Expiry is the shortest of:
     - the template's validity period
     - the CA's own configured cap
     - the remaining life of the CA certificate itself

   The template menu shows the template figure (e.g. "730d") so you know the
   intent up front. The real dates are read off the issued certificate and
   written to cert-info.txt and the CSV.

 PRIVATE KEY HYGIENE

   Each host's private key is generated on the CA, exported to the PFX, then
   deleted from the CA's store along with its key file. A CA holding exportable
   private keys for every server in the estate is a liability. Use
   -KeepInStore only if you have a specific reason.

--------------------------------------------------------------------------------
 PART 2 - INSTALL A CERTIFICATE (on each target server)
--------------------------------------------------------------------------------

 Copy the host's ZIP to that server, extract it, then:

   Install-RdpCertificate.bat srv-app01.corp.example.com.pfx

 Or drag the PFX onto the BAT. It prompts for the password, then:
   - imports the certificate and its chain to the correct stores
   - grants the Remote Desktop service read access to the private key
   - binds the thumbprint to the RDP-Tcp listener
   - sets SecurityLayer=2 (TLS) and UserAuthentication=1 (NLA)
   - verifies the binding actually took effect

 Switches:
   -RestartService   restart TermService afterwards. Not needed: the binding
                     applies to new connections immediately. It will drop every
                     current RDP session, including yours.
   -Strict           treat certificate warnings (expiry, missing SAN, untrusted
                     issuer) as failures instead of warnings
   -Exportable       allow the imported key to be exported again

 The private key ACL step is the one that matters most. Without it the binding
 reports success but RDP quietly keeps presenting its self-signed certificate.

--------------------------------------------------------------------------------
 PART 3 - SIGN CSRs MADE ELSEWHERE (on the CA)
--------------------------------------------------------------------------------

 Use this when the requester generated their own key pair and sent you only a
 CSR: Linux boxes, nginx, Apache, Java keytool, F5, NetScaler, appliances, or an
 IIS server that created a pending request locally.

 The private key never reaches the CA, so there is NO PFX and NO password. The
 output is not secret and can be emailed back as-is.

 USAGE

   Interactive:
     Right-click Sign-Requests.bat  >  Run as administrator
       1  pick a template
       2  SINGLE (one CSR file) or BULK (every CSR in a folder)
       3  the file or folder path
       4  review the parsed table, then y

   Drag and drop:
     Drag a .req/.csr file, or a folder of them, onto Sign-Requests.bat.

   Non-interactive:
     Sign-Requests.bat -Template WebServer -CsrPath C:\tmp\csr\
     Sign-Requests.bat -Template WebServer -CsrPath C:\tmp\web01.req

   Switches:
     -CsrPath <file|folder>    a single CSR, or a folder to process in bulk
     -Filter *.req,*.csr       which extensions count as a CSR in bulk mode
                               default: *.req *.csr *.pem *.txt *.p10
     -ExportRoot <path>        base output folder          (default C:\tmp)
     -MinKeyLength 3072        minimum RSA key size           (default 2048)
     -MinEcKeyLength 384       minimum EC key size            (default 256)
     -Strict                   treat CSR warnings as failures
     -NoPrompt                 ask nothing; needs -Template and -CsrPath
     -AddSan a,b               add a SAN at signing time - see the warning below

 WHAT IT CHECKS IN EACH CSR BEFORE SUBMITTING

   Parsed with certutil and reported as a table:
     Common Name, full subject, key algorithm and size, signature algorithm,
     and every DNS and IP SAN entry.

   Refused outright:
     not a PKCS#10 request (e.g. you passed an issued certificate by mistake)
     no Common Name
     RSA key smaller than -MinKeyLength, or EC key smaller than -MinEcKeyLength
       (the two are checked separately: a 256-bit EC key is roughly as strong
        as a 3072-bit RSA key, so one floor cannot serve both)
     a DSA key, which is not usable for TLS
     unreadable or corrupt file

   Warned about (use -Strict to make these refusals):
     no Subject Alternative Name - current clients reject such certificates
     SHA-1 or MD5 signed CSR - usually a sign of old tooling
     a CN that is not a valid DNS name
     a key below the TEMPLATE minimum, which the CA will deny anyway

 TEMPLATE REQUIREMENTS DIFFER FROM PART 1

   Needed:     Subject Name > "Supply in the request"
   NOT needed: "Allow private key to be exported" - there is no key here

   If the template builds the subject from AD, the CA discards the CSR's subject
   AND its SAN. The script warns before submitting and, if it detects it after
   the fact, discards that certificate, prints the revoke command and stops the
   run so you do not sign a whole folder of useless certificates.

 OUTPUT

   C:\tmp\SignedCerts_<yyyyMMdd_HHmmss>\
       web01.corp.example.com.zip
       signing-log_<timestamp>.csv

   Each ZIP contains:
       <name>.cer              issued certificate, DER - for Windows and IIS
       <name>.pem              issued certificate, PEM - for Linux
       <name>-fullchain.pem    certificate + chain - what nginx wants
       ca-chain.pem            intermediates then root
       ca-root.pem             root CA only - upload this to Nessus
       ca-intermediate.pem     issuing CA(s), if any
       ca-chain.p7b            the chain in PKCS#7, for Windows import
       <original>.req          the request you were sent, kept for the record
       cert-info.txt           details plus ready-made nginx/Apache/IIS snippets

 CSRs WITH NO SAN

   The correct fix is a new CSR that includes the SAN. -AddSan can inject names
   at signing time instead, but ONLY if the CA has EDITF_ATTRIBUTESUBJECTALTNAME2
   enabled. That flag lets any enroller request any name, including names they do
   not own, and is a recognised security weakness. The script detects whether it
   is set, refuses -AddSan if it is not, and never enables it for you.

   Note also that the attribute applies to EVERY request in the run, so it is
   only sensible when signing a single CSR.

 INSTALLING THE RESULT ON THE REQUESTER'S MACHINE

   nginx     ssl_certificate     /path/<name>-fullchain.pem;
             ssl_certificate_key /path/their-existing.key;

   Apache    SSLCertificateFile      /path/<name>.pem
             SSLCertificateKeyFile   /path/their-existing.key
             SSLCertificateChainFile /path/ca-chain.pem

   IIS       On the server that created the request:
             certreq -accept <name>.cer

   The key must be the one already on that machine. A certificate signed from a
   CSR will not work with any other key.

--------------------------------------------------------------------------------
 PART 4 - "THEY WANT A PFX, BUT I ONLY SIGNED A CSR"
--------------------------------------------------------------------------------

 A PFX contains the PRIVATE KEY. With a CSR the key never leaves the requester's
 machine, so the CA cannot build a PFX - it only ever saw the public half. There
 is no setting that changes this; it is how CSRs work.

 So the PFX is built where the key already is. Three ways, pick by how the CSR
 was made.

 A. THE CSR CAME FROM A WINDOWS MACHINE (certreq or the IIS console)

    Windows is holding the key against a pending request on that machine. Copy
    the signed .cer there and run, elevated:

        certreq -accept web01.corp.example.com.cer

    That marries the certificate to the waiting key and installs it. For IIS
    that is usually all that is needed - no PFX at all. If they still want a
    PFX file, drag the .cer onto Make-Pfx.bat on that machine, or:

        Convert-ToPfx.ps1 -CertificatePath web01.cer -ChainPath ca-chain.pem

    This only works if the key was created exportable. A non-exportable key
    cannot be extracted afterwards - the certificate still works on that
    machine, but no PFX can ever be produced from it.

 B. THE CSR CAME FROM OPENSSL (Linux, nginx, Apache, most appliances)

    They have the .key file next to the CSR. On any machine with OpenSSL:

        openssl pkcs12 -export \
            -inkey  web01.key \
            -in     web01.pem \
            -certfile ca-chain.pem \
            -out    web01.pfx

    Or on Windows, with both files to hand:

        Convert-ToPfx.ps1 -CertificatePath web01.pem -KeyPath web01.key -ChainPath ca-chain.pem

    The script finds openssl.exe itself (including the copy inside Git for
    Windows), compares the key and certificate moduli first so a mismatched key
    is reported plainly instead of as an obscure OpenSSL error, and prints the
    exact command to run elsewhere if OpenSSL is missing.

 C. THE CSR CAME FROM JAVA KEYTOOL

    The key is inside the keystore. Import the chain, then the certificate, into
    the SAME keystore and alias that generated the request:

        keytool -import -alias root  -file ca-root.pem         -keystore app.jks
        keytool -import -alias inter -file ca-intermediate.pem -keystore app.jks
        keytool -import -alias myapp -file web01.pem           -keystore app.jks

    To get a PFX/PKCS#12 out of it afterwards:

        keytool -importkeystore -srckeystore app.jks -srcalias myapp \
                -destkeystore web01.pfx -deststoretype PKCS12

 IF THEY SIMPLY WANT A PFX AND HAVE NO KEY YET

    Do not ask them for a CSR at all. Use PART 1 instead: that script generates
    the key pair on the CA and hands you a finished PFX per host. Use CSR
    signing (PART 3) only when the requester must keep their own key, which is
    the norm for appliances and anything that generated a key internally.

 THE PRIVATE KEY MISMATCH TRAP

    A certificate signed from a CSR works with exactly ONE private key - the one
    whose public half was in that CSR. If someone regenerates the key, or sends
    the wrong .key file, no PFX can be built and no amount of re-signing helps.
    Convert-ToPfx.ps1 checks this up front and says so.

--------------------------------------------------------------------------------
 FIRST RUN - TEST BEFORE BULK
--------------------------------------------------------------------------------

 1. On the CA, issue one certificate for a name that is not a real server:

      Issue-Certificates.bat -ComputerName testhost01

 2. Open the .cer inside the ZIP and check three things:

      - Subject is CN=testhost01.<yourdomain>, NOT the CA's own name.
        If it shows the CA's name, the template is building the subject from
        Active Directory. Fix the template; do not proceed to bulk.
      - The SAN field lists both the FQDN and the short name.
      - Validity dates match what you expect from the template.

 3. Import the PFX somewhere with the password, to confirm the private key
    travelled and the chain came with it.

 4. Only then run the bulk list. Try three or four names before three hundred.

--------------------------------------------------------------------------------
 EXIT CODES  (both CA scripts)
--------------------------------------------------------------------------------

   0   success
   1   completed, but one or more hosts failed (see the CSV log)
   2   cancelled by the operator
   3   prerequisites not met, nothing submitted

--------------------------------------------------------------------------------
 TROUBLESHOOTING
--------------------------------------------------------------------------------

 Template menu looks garbled or shows phantom entries
   certutil -CATemplates output format varies slightly between builds. Capture
   the raw output and the parsing regex can be adjusted.

 0x80090017 NTE_PROV_TYPE_NOT_DEF during "creating and exporting"
   Provider family mismatch. The template is legacy-CSP only but a Key Storage
   Provider request was made, or the reverse. The script now reads the
   template's schema version and Use Legacy Provider flag from AD and picks the
   matching family, then retries with the other family if the first is
   rejected. To force it:

     Issue-Certificates.bat -Template <name> -LegacyCsp        (SChannel CSP)
     Issue-Certificates.bat -Template <name> -Provider KSP     (CNG KSP)

   Check which your template wants: CA console > Certificate Templates >
   your template > Properties > Cryptography > Provider Category.
     "Legacy Cryptographic Service Provider"  -> CSP
     "Key Storage Provider"                   -> KSP

   The provider actually used for each host is recorded in the CSV log.

 "key generation failed" for another reason
   The message carries certreq's own output. Common causes are the template not
   being published on this CA, no enroll permission, or a key length below the
   template minimum.

 Hosts come back as "Pending"
   The template requires CA manager approval. The script reports the RequestId
   and the exact certreq -retrieve command, and carries on with the rest.

 "the CA denied the request"
   Usually enrollment permissions on the template, or the template is not
   actually published on this CA.

 Issued certificate has no CN / no OU / wrong name
   The template's Subject Name tab is set to "Build from this Active Directory
   information". ADCS then throws away the requested subject. Fix:
     CA console > Certificate Templates > template > Properties
     Subject Name tab > "Supply in the request"
   Built-in templates are read-only: Duplicate first, set Supply in the
   request, allow private key export, then publish the duplicate via
   Certificate Templates > New > Certificate Template to Issue.
   Revoke anything already issued from the bad template:
     certutil -revoke <serial> 4

   Check any certificate yourself:
     certutil -dump srv-app01.corp.example.com.cer
   Look at "Subject:" and the "Subject Alternative Name" extension.

 SIGNING ECC / ECDSA CSRs
--------------------------------------------------------------------------------

 Yes, this works - but it depends on the TEMPLATE, not on the script and not on
 the CA's own key.

 WHAT DOES NOT MATTER
   The CA's own key can be RSA. An RSA CA signs EC requests perfectly well: the
   issued certificate carries the requester's EC public key and an RSA signature
   from the CA. That is completely standard. You do not need an ECC CA.

 WHAT DOES MATTER - the template needs all three
   Compatibility tab : CA and recipient both Windows Server 2012 or later
                       (this makes it schema v3+; v1 and v2 templates are
                        legacy-CSP only and cannot carry EC keys at all)
   Cryptography tab  : Provider Category = Key Storage Provider
                       Algorithm name    = ECDSA_P256 (or P384/P521)
                       Minimum key size  = 256
   Subject Name tab  : Supply in the request

 WHY THE MINIMUM KEY SIZE TRIPS PEOPLE UP
   ADCS compares the raw bit count. A P-256 key is 256 bits, so a template whose
   minimum is 2048 denies it - even though P-256 is roughly as strong as
   RSA-3072. The number is smaller; the key is not weaker.

 MAKING THE TEMPLATE (once, then reuse)
   CA console > Certificate Templates > right-click > Manage
   Duplicate a Web Server template, set the three tabs above, name it e.g.
   WebServerECC, then publish it:
   Certificate Templates > New > Certificate Template to Issue

 WHAT THE SCRIPT DOES ABOUT IT
   When any CSR in the run uses an EC key, the script checks the template before
   submitting and prints a verdict:

     3 request(s) use elliptic-curve keys. Checking template compatibility...
       Template algorithm : ECDSA_P256
       Template schema    : v4
       Template min key   : 256
       Request            : web01.csr  P-256 (prime256v1), 256 bits
       Template looks compatible with these EC requests.

   If it is not compatible it names the reason, prints the exact template
   settings to change, and offers to submit anyway so the CA can have the final
   say. With -NoPrompt it refuses rather than wasting request IDs.

 MIXED RSA AND EC IN ONE FOLDER
   A template is either RSA or ECC, not both, so one bulk run cannot sign both
   kinds. Sort the CSRs into two folders and make two runs with the matching
   template for each.

--------------------------------------------------------------------------------
 "key is 256 bits, below the 2048-bit minimum" when signing a CSR
   A 256-bit key is an elliptic-curve (P-256) key, not a weak RSA key. EC keys
   are numerically much smaller than RSA for the same strength: P-256 is roughly
   equivalent to RSA-3072. The script now detects the key family from its OID
   and applies separate floors, so EC CSRs are accepted.

   If the CA then DENIES the request, the template is the problem, not the key.
   ADCS compares the raw bit count, so an EC request against a template whose
   minimum key size is 2048 is denied. Either:
     - use a template whose Cryptography tab specifies an ECC provider with a
       minimum key size of 256, or
     - have the requester generate an RSA key instead:
         openssl req -new -newkey rsa:2048 -nodes -keyout host.key -out host.csr

   The script warns about this mismatch before submitting anything.

 Nessus: "SSL Certificate Cannot Be Trusted" (plugin 51192)
   Nessus does not know your internal root CA. Upload ca-root.pem (and
   ca-intermediate.pem if present) to the scanner's custom CA setting, then
   rescan. On the server side the chain must also be served: the install script
   places intermediates in LocalMachine\CA so Schannel sends them.

 Nessus: "SSL Certificate with Wrong Hostname" (plugin 45411)
   The scan targets the server by IP but the certificate only names it by DNS.
   Re-issue with -IncludeIpAddress, or scan by FQDN.

 Nessus: "SSL Self-Signed Certificate" (plugin 57582) on 3389
   The new certificate is not bound. Re-run the install script; if it passes
   but the finding remains, fix the private key ACL as below.

 RDP still shows a self-signed certificate after install
   The private key ACL did not apply. Open certlm.msc, find the certificate in
   Personal, right-click > All Tasks > Manage Private Keys, and give
   NETWORK SERVICE read access.

 Verify from a client:
   openssl s_client -connect srv-app01.corp.example.com:3389 -starttls rdp
