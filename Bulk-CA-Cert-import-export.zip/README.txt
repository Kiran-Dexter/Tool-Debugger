================================================================================
 RDP / TLS CERTIFICATE TOOLKIT
 Windows Server 2012, 2012 R2, 2016, 2019, 2022, 2025
================================================================================

 IMPORTANT: these scripts have not been executed against a live CA. They are
 written to documented ADCS and certreq behaviour. Do a single-host test run
 before feeding in a bulk list. See "FIRST RUN" below.

--------------------------------------------------------------------------------
 CONTENTS
--------------------------------------------------------------------------------

 Run on the CA
   Issue-Certificates.bat            launcher - double-click this
   New-BulkHostCertificate.ps1       does the work
   hosts.txt                         sample bulk input file

 Run on each target server
   Install-RdpCertificate.bat        launcher - double-click this
   Install-RdpCertificate.ps1        does the work

 Both BAT files must stay in the same folder as their matching PS1.
 Extract the whole ZIP; do not move files out individually.

--------------------------------------------------------------------------------
 PART 1 - ISSUE CERTIFICATES (on the CA)
--------------------------------------------------------------------------------

 PREREQUISITES - checked automatically before anything is submitted

   The script runs ten checks and reports all failures at once, with a remedy
   for each. It exits with code 3 and submits nothing if any fail.

     1  Elevated session
     2  PowerShell 3.0 or later
     3  .NET Framework 4.5 or later (for ZIP support)
     4  certreq.exe present
     5  certutil.exe present
     6  ADCS role installed and this machine is the CA
     7  CertSvc service running
     8  Machine is domain-joined
     9  AD configuration partition reachable over LDAP
    10  C:\tmp writable, and TEMP writable

   Not machine-checkable, so confirm manually:
     - Your account has "Request Certificates" on the CA.
     - The template you pick has BOTH of these, or the script will warn:
         * Subject Name  >  Supply in the request
         * Request Handling  >  Allow private key to be exported
       Stock templates usually have neither. Duplicate a Web Server template
       and enable both.

 USAGE

   Interactive (recommended):
     Right-click Issue-Certificates.bat  >  Run as administrator

     It will then ask you to:
       a) pick a template from a numbered list
       b) choose SINGLE or BULK
       c) give a hostname, or the path to your hosts file
       d) type the PFX password twice

   Non-interactive:
     Issue-Certificates.bat -Template WebServerExportable -HostFile C:\tmp\hosts.txt
     Issue-Certificates.bat -ComputerName SRV-APP01
     Issue-Certificates.bat -Template WebServerExportable -ExportRoot D:\certs

   Useful switches:
     -ExportRoot <path>        base output folder          (default C:\tmp)
     -Domain <dns.domain>      suffix for bare hostnames   (default: CA's own)
     -KeyLength 4096           key size                    (default 2048)
     -IncludeShortName:$false  omit the NetBIOS name from the SAN
     -LegacyCsp                use the SChannel CSP for old v1 templates
     -KeepInStore              leave private keys on the CA (not recommended)

 OUTPUT

   C:\tmp\HostCerts_<yyyyMMdd_HHmmss>\
       srv-app01.corp.example.com.zip
       srv-app02.corp.example.com.zip
       ...
       issuance-log_<timestamp>.csv

   Each ZIP contains four files:
       <fqdn>.pfx          certificate + private key + full CA chain,
                           encrypted with the password you typed
       <fqdn>.cer          the issued certificate alone, no private key
       ca-chain.cer        CA and root certificates in PEM text form
       cert-info.txt       subject, issuer, serial, thumbprint, validity dates,
                           template used, key length, SAN entries

   The ZIP container itself is NOT encrypted. The PFX inside is. Move the files
   over a trusted channel.

 CERTIFICATE VALIDITY

   The script never requests a lifetime, because an Enterprise CA ignores any
   lifetime asked for in a CSR. Expiry is the shortest of:
     - the template's validity period
     - the CA's own configured cap
     - the remaining life of the CA certificate itself

   The template menu shows the template figure (e.g. "730d") so you know the
   intent up front. The real dates are read off the issued certificate and
   written to cert-info.txt and the CSV.

 PRIVATE KEY HYGIENE

   Each host's private key is generated on the CA, exported to the PFX, then
   deleted from the CA's store along with its key file. A CA holding exportable
   private keys for every server in the estate is a liability. Use
   -KeepInStore only if you have a specific reason.

--------------------------------------------------------------------------------
 PART 2 - INSTALL A CERTIFICATE (on each target server)
--------------------------------------------------------------------------------

 Copy the host's ZIP to that server, extract it, then:

   Install-RdpCertificate.bat srv-app01.corp.example.com.pfx

 Or drag the PFX onto the BAT. It prompts for the password, then:
   - imports the certificate and its chain to the correct stores
   - grants the Remote Desktop service read access to the private key
   - binds the thumbprint to the RDP-Tcp listener
   - sets SecurityLayer=2 (TLS) and UserAuthentication=1 (NLA)
   - verifies the binding actually took effect

 Switches:
   -RestartService   restart TermService afterwards. Not needed: the binding
                     applies to new connections immediately. It will drop every
                     current RDP session, including yours.
   -Strict           treat certificate warnings (expiry, missing SAN, untrusted
                     issuer) as failures instead of warnings
   -Exportable       allow the imported key to be exported again

 The private key ACL step is the one that matters most. Without it the binding
 reports success but RDP quietly keeps presenting its self-signed certificate.

--------------------------------------------------------------------------------
 FIRST RUN - TEST BEFORE BULK
--------------------------------------------------------------------------------

 1. On the CA, issue one certificate for a name that is not a real server:

      Issue-Certificates.bat -ComputerName testhost01

 2. Open the .cer inside the ZIP and check three things:

      - Subject is CN=testhost01.<yourdomain>, NOT the CA's own name.
        If it shows the CA's name, the template is building the subject from
        Active Directory. Fix the template; do not proceed to bulk.
      - The SAN field lists both the FQDN and the short name.
      - Validity dates match what you expect from the template.

 3. Import the PFX somewhere with the password, to confirm the private key
    travelled and the chain came with it.

 4. Only then run the bulk list. Try three or four names before three hundred.

--------------------------------------------------------------------------------
 EXIT CODES
--------------------------------------------------------------------------------

   0   success
   1   completed, but one or more hosts failed (see the CSV log)
   2   cancelled by the operator
   3   prerequisites not met, nothing submitted

--------------------------------------------------------------------------------
 TROUBLESHOOTING
--------------------------------------------------------------------------------

 Template menu looks garbled or shows phantom entries
   certutil -CATemplates output format varies slightly between builds. Capture
   the raw output and the parsing regex can be adjusted.

 "key generation failed" on every host
   Re-run with -LegacyCsp. Some old v1 templates reject Key Storage Provider
   requests and need the SChannel CSP instead.

 Hosts come back as "Pending"
   The template requires CA manager approval. The script reports the RequestId
   and the exact certreq -retrieve command, and carries on with the rest.

 "the CA denied the request"
   Usually enrollment permissions on the template, or the template is not
   actually published on this CA.

 RDP still shows a self-signed certificate after install
   The private key ACL did not apply. Open certlm.msc, find the certificate in
   Personal, right-click > All Tasks > Manage Private Keys, and give
   NETWORK SERVICE read access.

 Verify from a client:
   openssl s_client -connect srv-app01.corp.example.com:3389 -starttls rdp
