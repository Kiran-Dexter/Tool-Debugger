@echo off
setlocal EnableExtensions

echo ==========================================
echo     CA Certificate Request Signing
echo     Signs CSRs made on other machines
echo     Run this ON the issuing CA
echo ==========================================
echo.

net session >nul 2>&1
if errorlevel 1 (
    echo [FAIL] Not running elevated.
    echo        Right-click this BAT and choose "Run as administrator".
    echo.
    pause
    exit /b 3
)

where powershell.exe >nul 2>&1
if errorlevel 1 (
    echo [FAIL] powershell.exe not found in PATH.
    echo.
    pause
    exit /b 3
)

where certreq.exe >nul 2>&1
if errorlevel 1 (
    echo [FAIL] certreq.exe not found. This does not look like a CA.
    echo.
    pause
    exit /b 3
)

set "SCRIPT=%~dp0Sign-CertificateRequest.ps1"
if not exist "%SCRIPT%" (
    echo [FAIL] Sign-CertificateRequest.ps1 must sit next to this BAT.
    echo        Expected: %SCRIPT%
    echo        Extract the whole ZIP, keeping the files together.
    echo.
    pause
    exit /b 3
)

rem A dragged-and-dropped CSR file or folder arrives as %1.
set "DROPPED=%~1"

if defined DROPPED (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -CsrPath "%DROPPED%" %2 %3 %4 %5
) else (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" %*
)
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo ==========================================
    echo COMPLETED - all requests signed
    echo Output: C:\tmp\SignedCerts_^<timestamp^>
    echo ==========================================
) else if "%RC%"=="2" (
    echo ==========================================
    echo CANCELLED - nothing was signed
    echo ==========================================
) else if "%RC%"=="3" (
    echo ==========================================
    echo PREREQUISITES NOT MET - nothing was submitted to the CA
    echo Fix the items marked [FAIL] above and re-run.
    echo ==========================================
) else (
    echo ==========================================
    echo COMPLETED WITH ERRORS - exit code %RC%
    echo Check signing-log_*.csv in the output folder.
    echo ==========================================
)

echo.
pause
exit /b %RC%
