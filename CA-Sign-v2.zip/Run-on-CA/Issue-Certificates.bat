@echo off
setlocal EnableExtensions

echo ==========================================
echo     CA Bulk Certificate Issuance
echo     Run this ON the issuing CA
echo ==========================================
echo.

rem ---------- launcher-level prerequisites ----------
rem The PS1 runs a full prerequisite batch of its own; these three checks only
rem exist so we can fail with a readable message instead of a PowerShell stack.

net session >nul 2>&1
if errorlevel 1 (
    echo [FAIL] Not running elevated.
    echo        Right-click this BAT and choose "Run as administrator".
    echo.
    pause
    exit /b 3
)

where powershell.exe >nul 2>&1
if errorlevel 1 (
    echo [FAIL] powershell.exe not found in PATH.
    echo.
    pause
    exit /b 3
)

set "SCRIPT=%~dp0New-BulkHostCertificate.ps1"
if not exist "%SCRIPT%" (
    echo [FAIL] New-BulkHostCertificate.ps1 must sit next to this BAT.
    echo        Expected: %SCRIPT%
    echo        Extract the whole ZIP, keeping the files together.
    echo.
    pause
    exit /b 3
)

rem ---------- run ----------
rem Any parameters are passed straight through, for example:
rem   Issue-Certificates.bat -Template WebServerExportable -HostFile C:\tmp\hosts.txt
rem   Issue-Certificates.bat -ComputerName SRV-APP01
rem   Issue-Certificates.bat -ExportRoot D:\certs

echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" %*
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo ==========================================
    echo COMPLETED - all requested certificates issued
    echo Output: C:\tmp\HostCerts_^<timestamp^>  ^(unless -ExportRoot was used^)
    echo ==========================================
) else if "%RC%"=="2" (
    echo ==========================================
    echo CANCELLED - nothing was issued
    echo ==========================================
) else if "%RC%"=="3" (
    echo ==========================================
    echo PREREQUISITES NOT MET - nothing was submitted to the CA
    echo Fix the items marked [FAIL] above and re-run.
    echo ==========================================
) else (
    echo ==========================================
    echo COMPLETED WITH ERRORS - exit code %RC%
    echo Some hosts failed. Check issuance-log_*.csv in the output folder.
    echo ==========================================
)

echo.
pause
exit /b %RC%
