<#
.SYNOPSIS
    Interactive bulk certificate issuance on a Microsoft Enterprise CA.
    Issues server certificates for one host or a list of hosts and packages each
    one as its own password-protected PFX inside its own ZIP.

.DESCRIPTION
    Run this ON the issuing CA, elevated.

    Flow:
      1. Detects the local CA config string and the AD domain it serves.
      2. Lists the certificate templates published on this CA and lets you pick one.
      3. Inspects the template in AD and warns about anything that would produce
         a certificate you cannot use (subject not enrollee-supplied, key not
         exportable, no Server Authentication EKU, minimum key size).
      4. Asks for SINGLE or BULK. Bulk reads a plain text file, one hostname per
         line, any case, comments and blanks ignored.
      5. Normalizes every name to lowercase, appends the CA's own domain to bare
         hostnames, validates DNS syntax, de-duplicates.
      6. Prompts once for the PFX password (twice, confirmed).
      7. Per host: builds an INF, generates the key, submits to the CA, accepts
         the issued certificate, exports a full-chain PFX, zips it, and removes
         the private key from the CA's store.
      8. Prints a summary table and writes a CSV log. Any single host failing
         does not stop the run.

    Compatible with Windows Server 2012, 2012 R2, 2016, 2019, 2022, 2025
    (PowerShell 3.0+, .NET 4.5+).

.PARAMETER Template
    Template CN, to skip the interactive menu.

.PARAMETER HostFile
    Path to the hostname list. Implies bulk mode.

.PARAMETER ComputerName
    A single hostname. Implies single mode.

.PARAMETER Domain
    DNS domain suffix for bare hostnames. Defaults to the CA's own AD domain.

.PARAMETER ExportRoot
    Base folder for exports. Defaults to C:\tmp. Created if missing, and tested
    for writability during the prerequisite checks.

.PARAMETER OutputPath
    Exact folder for this run's ZIPs. Defaults to
    <ExportRoot>\HostCerts_<yyyyMMdd_HHmmss>, so runs never overwrite each other.

.PARAMETER Password
    PFX password as a SecureString. Prompted for if omitted.

.PARAMETER KeyLength
    RSA key size. Raised automatically if the template demands more. Default 2048.

.PARAMETER IncludeShortName
    Add the bare hostname to the SAN alongside the FQDN. On by default; use
    -IncludeShortName:$false to suppress.

.PARAMETER Provider
    Auto (default), KSP or CSP. Auto reads the template's schema version and
    its Use Legacy Provider flag out of AD and picks the matching provider
    family. If the first choice is rejected with a provider-type error the
    script retries with the other family automatically.

.PARAMETER LegacyCsp
    Shorthand for -Provider CSP. Forces the SChannel CSP, which is what schema
    v1 and v2 templates require.

.PARAMETER OrganizationalUnit
    One or more OU values for the certificate subject, e.g. -OrganizationalUnit IT
    or -OrganizationalUnit 'IT','Servers'. Optional.

.PARAMETER Organization
    O= value for the subject, e.g. 'Example Corp'. Optional.

.PARAMETER Locality
    L= value (city). Optional.

.PARAMETER State
    S= value (state or province). Optional.

.PARAMETER Country
    C= value, two-letter ISO code such as SG or US. Optional.

.PARAMETER NoPrompt
    Skip every interactive question and use defaults for anything not passed as
    a parameter. For scheduled or unattended runs. -Template and either
    -HostFile or -ComputerName, plus -Password, must then be supplied.

.PARAMETER AdditionalSan
    Extra DNS names added to the SAN of EVERY host in the run, e.g.
    -AdditionalSan 'rdp.corp.example.com','vip-app.corp.example.com'.
    Use this for a name shared by all hosts (a load-balancer VIP, a cluster
    name). For names that differ per host, list them in the hosts file after
    the primary name, separated by commas.

.PARAMETER IncludeIpAddress
    Resolve each host in DNS and add its IPv4 addresses to the SAN. Needed if a
    scanner such as Nessus targets servers by IP rather than by name, otherwise
    it reports a hostname mismatch.

.PARAMETER KeepInStore
    Leave the issued certificate and private key in the CA's LocalMachine\My
    store. Off by default: the CA should not accumulate other hosts' keys.

.EXAMPLE
    .\New-BulkHostCertificate.ps1

.EXAMPLE
    .\New-BulkHostCertificate.ps1 -Template WebServerExportable -HostFile C:\hosts.txt

.EXAMPLE
    .\New-BulkHostCertificate.ps1 -Template WebServerExportable -ComputerName SRV-APP01
#>
[CmdletBinding()]
param(
    [string] $Template,
    [string] $HostFile,
    [string] $ComputerName,
    [string] $Domain,
    [string] $OutputPath,
    [string] $ExportRoot = 'C:\tmp',
    [System.Security.SecureString] $Password,
    [int]    $KeyLength = 2048,
    [switch] $IncludeShortName = $true,
    [ValidateSet('Auto', 'KSP', 'CSP')]
    [string] $Provider = 'Auto',
    [switch] $LegacyCsp,
    [switch] $KeepInStore,
    [string[]] $OrganizationalUnit,
    [string] $Organization,
    [string] $Locality,
    [string] $State,
    [string] $Country,
    [switch] $IncludeIpAddress,
    [string[]] $AdditionalSan,
    [switch] $NoPrompt
)

$ErrorActionPreference = 'Stop'
$OID_SERVER_AUTH = '1.3.6.1.5.5.7.3.1'

# Template flag bits we care about.
$CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT = 0x00000001
$CT_FLAG_SUBJECT_ALT_REQUIRE_DNS   = 0x08000000
$CT_FLAG_EXPORTABLE_KEY            = 0x00000010

# ============================================================ helpers

function Write-Banner {
    param([string] $Text)
    Write-Host ''
    Write-Host ('=' * 62) -ForegroundColor DarkCyan
    Write-Host ("  {0}" -f $Text) -ForegroundColor Cyan
    Write-Host ('=' * 62) -ForegroundColor DarkCyan
}

function Write-Step {
    param([string] $Message)
    Write-Host ''
    Write-Host ("--> {0}" -f $Message) -ForegroundColor Yellow
}

function ConvertFrom-SecureStringPlain {
    param([System.Security.SecureString] $Secure)
    $ptr = [System.Runtime.InteropServices.Marshal]::SecureStringToGlobalAllocUnicode($Secure)
    try   { [System.Runtime.InteropServices.Marshal]::PtrToStringUni($ptr) }
    finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeGlobalAllocUnicode($ptr) }
}

function Test-DnsName {
    <# RFC 1123 host name validation, post-lowercasing. #>
    param([string] $Name)
    if ([string]::IsNullOrWhiteSpace($Name)) { return 'empty' }
    if ($Name.Length -gt 253)                { return 'longer than 253 characters' }
    if ($Name -match '^[.-]|[.-]$')          { return 'starts or ends with a dot or hyphen' }
    if ($Name -match '\.\.')                 { return 'contains an empty label' }
    foreach ($label in ($Name -split '\.')) {
        if ($label.Length -gt 63)                  { return "label '$label' exceeds 63 characters" }
        if ($label -notmatch '^[a-z0-9]([a-z0-9-]*[a-z0-9])?$') { return "label '$label' has invalid characters" }
    }
    return $null
}

# ============================================================ preflight

Write-Banner 'CA Bulk Certificate Issuance'

<#
    Prerequisite checks run as a batch so you see every problem at once rather
    than fixing one, re-running, and hitting the next. Nothing is submitted to
    the CA until all of them pass.
#>

$checks   = New-Object System.Collections.ArrayList
$failures = New-Object System.Collections.ArrayList

function Add-Check {
    param(
        [string] $Name,
        [bool]   $Passed,
        [string] $Detail,
        [string] $Remedy
    )
    [void] $checks.Add((New-Object PSObject -Property @{
        Name   = $Name
        Passed = $Passed
        Detail = $Detail
        Remedy = $Remedy
    }))
    if (-not $Passed) { [void] $failures.Add($Name) }
}

Write-Step 'Checking prerequisites...'

# --- 1. elevation
$identity  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
$isAdmin   = $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
Add-Check -Name 'Elevated session' -Passed $isAdmin `
          -Detail $identity.Name `
          -Remedy 'Right-click the BAT and choose Run as administrator.'

# --- 2. PowerShell version
$psOk = $PSVersionTable.PSVersion.Major -ge 3
Add-Check -Name 'PowerShell 3.0+' -Passed $psOk `
          -Detail $PSVersionTable.PSVersion.ToString() `
          -Remedy 'Install Windows Management Framework 4.0 or later.'

# --- 3. .NET zip support
$zipOk = $false
try {
    Add-Type -AssemblyName 'System.IO.Compression.FileSystem' -ErrorAction Stop
    $zipOk = $true
} catch { }
Add-Check -Name '.NET 4.5 zip support' -Passed $zipOk `
          -Detail $(if ($zipOk) { 'System.IO.Compression.FileSystem loaded' } else { 'assembly unavailable' }) `
          -Remedy 'Install .NET Framework 4.5 or later.'

# --- 4. required executables
foreach ($exe in @('certreq.exe', 'certutil.exe')) {
    $found = $null
    try { $found = (Get-Command $exe -ErrorAction Stop).Source } catch { }
    Add-Check -Name $exe -Passed ([bool] $found) `
              -Detail $(if ($found) { $found } else { 'not found in PATH' }) `
              -Remedy 'Both ship with Windows. A missing one suggests a damaged install or a stripped PATH.'
}

# --- 5. ADCS installed and this is the CA
$caRegRoot = 'HKLM:\SYSTEM\CurrentControlSet\Services\CertSvc\Configuration'
$adcsOk    = Test-Path $caRegRoot
Add-Check -Name 'ADCS role present' -Passed $adcsOk `
          -Detail $(if ($adcsOk) { 'CertSvc configuration key found' } else { 'CertSvc configuration key missing' }) `
          -Remedy 'Run this script on the issuing CA itself, not on a member server.'

$activeCa = $null
if ($adcsOk) {
    $activeCa = (Get-ItemProperty -Path $caRegRoot -Name 'Active' -ErrorAction SilentlyContinue).Active
}
Add-Check -Name 'Active CA name' -Passed ([bool] $activeCa) `
          -Detail $(if ($activeCa) { $activeCa } else { 'could not read the Active value' }) `
          -Remedy 'The CA role appears installed but unconfigured. Complete the ADCS post-deployment configuration.'

# --- 6. CertSvc running
$certSvc   = Get-Service -Name CertSvc -ErrorAction SilentlyContinue
$svcOk     = ($certSvc -ne $null -and $certSvc.Status -eq 'Running')
Add-Check -Name 'CertSvc running' -Passed $svcOk `
          -Detail $(if ($certSvc) { $certSvc.Status.ToString() } else { 'service not found' }) `
          -Remedy 'Start the Active Directory Certificate Services service: Start-Service CertSvc'

# --- 7. domain membership
$computerSystem = $null
$domainOk = $false
try {
    $computerSystem = Get-WmiObject -Class Win32_ComputerSystem -ErrorAction Stop
    $domainOk = ($computerSystem.PartOfDomain -eq $true)
} catch { }
Add-Check -Name 'Domain joined' -Passed $domainOk `
          -Detail $(if ($computerSystem) { $computerSystem.Domain } else { 'could not query Win32_ComputerSystem' }) `
          -Remedy 'An Enterprise CA must be domain-joined. A standalone CA has no templates to enumerate.'

# --- 8. AD configuration partition reachable (needed for template flags)
$adOk = $false
$adDetail = 'not reachable'
try {
    $rootDseProbe = [ADSI]'LDAP://RootDSE'
    $adDetail = [string] $rootDseProbe.configurationNamingContext[0]
    $adOk = [bool] $adDetail
} catch {
    $adDetail = $_.Exception.Message
}
Add-Check -Name 'AD config partition' -Passed $adOk `
          -Detail $adDetail `
          -Remedy 'Template validation needs LDAP to a domain controller. Check DNS and that a DC is reachable.'

# --- 9. export root writable
$ExportRoot = $ExportRoot.TrimEnd('\')
$exportOk = $false
$exportDetail = $ExportRoot
try {
    if (-not (Test-Path -LiteralPath $ExportRoot)) {
        $null = New-Item -Path $ExportRoot -ItemType Directory -Force -ErrorAction Stop
        $exportDetail = "$ExportRoot (created)"
    }
    $probe = Join-Path $ExportRoot ("wtest_{0}.tmp" -f ([guid]::NewGuid().ToString('N')))
    Set-Content -LiteralPath $probe -Value 'x' -ErrorAction Stop
    Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
    $exportOk = $true
} catch {
    $exportDetail = "$ExportRoot - $($_.Exception.Message)"
}
Add-Check -Name 'Export folder writable' -Passed $exportOk `
          -Detail $exportDetail `
          -Remedy "Create the folder manually or pass -ExportRoot D:\some\other\path"

# --- 10. temp folder writable (working area for CSRs)
$tempOk = $false
$tempDetail = $env:TEMP
try {
    $probe = Join-Path $env:TEMP ("wtest_{0}.tmp" -f ([guid]::NewGuid().ToString('N')))
    Set-Content -LiteralPath $probe -Value 'x' -ErrorAction Stop
    Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
    $tempOk = $true
} catch {
    $tempDetail = "$env:TEMP - $($_.Exception.Message)"
}
Add-Check -Name 'TEMP writable' -Passed $tempOk `
          -Detail $tempDetail `
          -Remedy 'Key generation needs a writable TEMP folder.'

# --- report
Write-Host ''
foreach ($c in $checks) {
    if ($c.Passed) {
        Write-Host ('  [ OK ] {0,-24} {1}' -f $c.Name, $c.Detail) -ForegroundColor Green
    } else {
        Write-Host ('  [FAIL] {0,-24} {1}' -f $c.Name, $c.Detail) -ForegroundColor Red
    }
}

if ($failures.Count -gt 0) {
    Write-Host ''
    Write-Host ("{0} prerequisite check(s) failed. Nothing has been submitted to the CA." -f $failures.Count) -ForegroundColor Red
    Write-Host ''
    foreach ($c in ($checks | Where-Object { -not $_.Passed })) {
        Write-Host ("  {0}" -f $c.Name) -ForegroundColor Red
        Write-Host ("    {0}" -f $c.Remedy) -ForegroundColor DarkYellow
    }
    Write-Host ''
    exit 3
}

Write-Host ''
Write-Host 'All prerequisites satisfied.' -ForegroundColor Green

# --- derived CA identity
$caDomain = $computerSystem.Domain.ToLower()
$caFqdn   = ("{0}.{1}" -f $env:COMPUTERNAME, $caDomain).ToLower()
$caConfig = "$caFqdn\$activeCa"

if (-not $Domain) { $Domain = $caDomain }
$Domain = $Domain.Trim().Trim('.').ToLower()

Write-Host ''
Write-Host ("CA host        : {0}" -f $caFqdn)
Write-Host ("CA name        : {0}" -f $activeCa)
Write-Host ("CA config      : {0}" -f $caConfig)
Write-Host ("Default domain : {0}" -f $Domain)
Write-Host ("Export root    : {0}" -f $ExportRoot)

Write-Step 'Pinging the CA...'
$ping = & certutil.exe -config "$caConfig" -ping 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host ($ping -join [Environment]::NewLine) -ForegroundColor DarkGray
    Write-Host ''
    Write-Host 'The CA did not answer. Common causes:' -ForegroundColor Red
    Write-Host '  - CertSvc is running but the CA is in a failed state (check the CA console)' -ForegroundColor DarkYellow
    Write-Host '  - the account running this script lacks Request Certificates permission on the CA' -ForegroundColor DarkYellow
    Write-Host '  - RPC is blocked between this session and the CA service' -ForegroundColor DarkYellow
    throw "The CA did not answer a ping on $caConfig."
}
Write-Host 'CA responded.' -ForegroundColor Green

# ============================================================ templates

function Get-PublishedTemplate {
    <#
        Templates actually published on this CA, enriched with the AD definition.
        certutil -CATemplates is the authoritative "what can this CA issue" list;
        AD supplies the flags that decide whether the result will be usable.
    #>

    $raw = & certutil.exe -CATemplates 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host ($raw -join [Environment]::NewLine) -ForegroundColor DarkGray
        throw 'certutil -CATemplates failed. Cannot enumerate templates.'
    }

    $published = @()
    foreach ($line in $raw) {
        # Format: "ShortName: Display Name -- Auto-Enroll" (suffix varies / may be absent)
        if ($line -match '^\s*([^:\s][^:]*):\s*(.+?)\s*$') {
            $cn      = $matches[1].Trim()
            $rest    = $matches[2].Trim()
            $display = ($rest -split '\s--\s')[0].Trim()
            if ($cn -eq 'CertUtil' -or $cn -like '*command completed*') { continue }
            $published += New-Object PSObject -Property @{
                CN          = $cn
                DisplayName = $display
            }
        }
    }

    if ($published.Count -eq 0) { throw 'No certificate templates are published on this CA.' }

    # AD template definitions
    $adTemplates = @{}
    try {
        $rootDse    = [ADSI]'LDAP://RootDSE'
        $configNc   = $rootDse.configurationNamingContext[0]
        $templateDn = "LDAP://CN=Certificate Templates,CN=Public Key Services,CN=Services,$configNc"
        $container  = [ADSI] $templateDn
        foreach ($child in $container.Children) {
            $cn = [string] $child.cn[0]
            $adTemplates[$cn] = $child
        }
    } catch {
        Write-Warning ("Could not read template definitions from AD: {0}" -f $_.Exception.Message)
        Write-Warning 'Continuing without template validation. Requests may be rejected or return unusable subjects.'
    }

    foreach ($t in $published) {
        $nameFlag   = $null
        $keyFlag    = $null
        $minKey     = $null
        $schema     = $null
        $ekus       = @()
        $validity   = $null

        $ad = $adTemplates[$t.CN]
        if ($ad) {
            try { $nameFlag = [int]  $ad.'msPKI-Certificate-Name-Flag'[0] }   catch { }
            try { $keyFlag  = [int]  $ad.'msPKI-Private-Key-Flag'[0] }        catch { }
            try { $minKey   = [int]  $ad.'msPKI-Minimal-Key-Size'[0] }        catch { }
            try { $schema   = [int]  $ad.'msPKI-Template-Schema-Version'[0] } catch { }
            try { $ekus     = @($ad.pKIExtendedKeyUsage) }                    catch { }
            try {
                $bytes = $ad.pKIExpirationPeriod[0]
                $ticks = [BitConverter]::ToInt64($bytes, 0)
                $validity = [TimeSpan]::FromTicks([Math]::Abs($ticks))
            } catch { }
        }

        Add-Member -InputObject $t -MemberType NoteProperty -Name NameFlag      -Value $nameFlag
        Add-Member -InputObject $t -MemberType NoteProperty -Name KeyFlag       -Value $keyFlag
        Add-Member -InputObject $t -MemberType NoteProperty -Name MinKeySize    -Value $minKey
        Add-Member -InputObject $t -MemberType NoteProperty -Name SchemaVersion -Value $schema
        Add-Member -InputObject $t -MemberType NoteProperty -Name Ekus          -Value $ekus
        Add-Member -InputObject $t -MemberType NoteProperty -Name Validity      -Value $validity
        Add-Member -InputObject $t -MemberType NoteProperty -Name InAd          -Value ([bool] $ad)
    }

    return ,($published | Sort-Object CN)
}

Write-Step 'Enumerating templates published on this CA...'
$templates = Get-PublishedTemplate
Write-Host ("{0} template(s) published." -f $templates.Count) -ForegroundColor Green

function Show-TemplateMenu {
    param($TemplateList)

    Write-Host ''
    Write-Host ('{0,-4} {1,-34} {2,-26} {3,-6} {4}' -f '#', 'Template CN', 'Display Name', 'Keys', 'Notes')
    Write-Host ('-' * 110)

    for ($i = 0; $i -lt $TemplateList.Count; $i++) {
        $t = $TemplateList[$i]
        $notes = @()

        if (-not $t.InAd) {
            $notes += 'not read from AD'
        } else {
            if ($t.NameFlag -ne $null -and -not ($t.NameFlag -band $CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT)) {
                $notes += 'subject built by CA'
            }
            if ($t.KeyFlag -ne $null -and -not ($t.KeyFlag -band $CT_FLAG_EXPORTABLE_KEY)) {
                $notes += 'key not exportable'
            }
            if ($t.Ekus.Count -gt 0 -and ($t.Ekus -notcontains $OID_SERVER_AUTH)) {
                $notes += 'no server auth EKU'
            }
            if ($t.Validity) {
                $notes += ('{0}d' -f [int] $t.Validity.TotalDays)
            }
        }

        $keyText = if ($t.MinKeySize) { [string] $t.MinKeySize } else { '?' }
        $noteText = if ($notes.Count) { $notes -join '; ' } else { 'OK' }
        $colour = if ($noteText -match 'not exportable|subject built by CA|no server auth') { 'DarkYellow' } else { 'Gray' }

        Write-Host ('{0,-4} {1,-34} {2,-26} {3,-6} {4}' -f `
            ($i + 1),
            $t.CN.Substring(0, [Math]::Min(34, $t.CN.Length)),
            $t.DisplayName.Substring(0, [Math]::Min(26, $t.DisplayName.Length)),
            $keyText,
            $noteText) -ForegroundColor $colour
    }
    Write-Host ''
}

$selected = $null

if ($Template) {
    $selected = $templates | Where-Object { $_.CN -eq $Template -or $_.DisplayName -eq $Template } | Select-Object -First 1
    if (-not $selected) {
        Show-TemplateMenu -TemplateList $templates
        throw "Template '$Template' is not published on this CA. Pick one of the names above."
    }
} elseif ($NoPrompt) {
    Show-TemplateMenu -TemplateList $templates
    throw 'With -NoPrompt you must pass -Template. Pick one of the names above.'
} else {
    Show-TemplateMenu -TemplateList $templates
    while (-not $selected) {
        $answer = Read-Host ("Select template number (1-{0}), or Q to quit" -f $templates.Count)
        if ($answer -match '^[Qq]') { Write-Host 'Cancelled.'; exit 2 }
        $index = 0
        if ([int]::TryParse($answer, [ref] $index) -and $index -ge 1 -and $index -le $templates.Count) {
            $selected = $templates[$index - 1]
        } else {
            Write-Host 'Not a valid selection.' -ForegroundColor Red
        }
    }
}

Write-Host ''
Write-Host ("Template       : {0}  ({1})" -f $selected.CN, $selected.DisplayName) -ForegroundColor Green

# ---- template suitability gate -------------------------------------------------

$blockers = @()
$advisories = @()

if ($selected.InAd) {
    if ($selected.NameFlag -ne $null -and -not ($selected.NameFlag -band $CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT)) {
        $blockers += 'The template does not allow the requester to supply the subject. The CA will overwrite your CN and SAN with the AD object of the account running this script, so every certificate would carry this CA''s name instead of the target host. Duplicate the template and tick "Supply in the request".'
    }
    if ($selected.KeyFlag -ne $null -and -not ($selected.KeyFlag -band $CT_FLAG_EXPORTABLE_KEY)) {
        $blockers += 'The template does not allow an exportable private key, so no PFX can be produced. Duplicate the template and tick "Allow private key to be exported".'
    }
    if ($selected.Ekus.Count -gt 0 -and ($selected.Ekus -notcontains $OID_SERVER_AUTH)) {
        $advisories += 'The template has no Server Authentication EKU. Certificates will not be accepted for TLS or RDP.'
    }
    if ($selected.MinKeySize -and $selected.MinKeySize -gt $KeyLength) {
        $advisories += ("Template minimum key size is {0}; raising the request from {1} to {0}." -f $selected.MinKeySize, $KeyLength)
        $KeyLength = $selected.MinKeySize
    }
}

if ($blockers.Count -gt 0) {
    Write-Host ''
    foreach ($b in $blockers) { Write-Warning $b }
    Write-Host ''
    $override = Read-Host 'These will almost certainly produce unusable certificates. Type PROCEED to continue anyway, anything else to abort'
    if ($override -ne 'PROCEED') { Write-Host 'Aborted.'; exit 2 }
}
foreach ($a in $advisories) { Write-Warning $a }

# ============================================================ host list

function Get-NormalizedHost {
    <#
        Lowercases, appends the default domain to bare names, validates syntax,
        de-duplicates. Returns normalized names plus a rejection list.
    #>
    param(
        [string[]] $RawName,
        [string]   $DefaultDomain
    )

    # Cleans one token: strips a pasted URL or :port, lowercases, and appends
    # the default domain to a bare hostname.
    function Resolve-Token {
        param([string] $Token, [string] $Suffix)
        $t = $Token.Trim().Trim('"').Trim("'").Trim()
        if ($t -eq '') { return $null }
        $t = $t -replace '^[a-z]+://', ''
        $t = ($t -split '[/:\\]')[0]
        $t = $t.ToLower().TrimEnd('.')
        if ($t -eq '') { return $null }
        if ($t.Contains('.')) { return $t }
        return "$t.$Suffix"
    }

    $accepted = New-Object System.Collections.ArrayList
    $rejected = New-Object System.Collections.ArrayList
    $seen     = @{}
    $lineNo   = 0

    foreach ($raw in $RawName) {
        $lineNo++
        if ($raw -eq $null) { continue }

        $line = $raw.Trim()
        if ($line -eq '')            { continue }
        if ($line -match '^\s*[#;]') { continue }   # comment lines

        # A line may carry extra SAN names after the primary one, separated by
        # commas or whitespace:   srv-app01, rdp-app01, app.corp.example.com
        # A trailing comma just yields an empty token, so old files still work.
        $tokens = @()
        foreach ($piece in ($line -split '[,;\s]+')) {
            $cleaned = Resolve-Token -Token $piece -Suffix $DefaultDomain
            if ($cleaned) { $tokens += $cleaned }
        }
        if ($tokens.Count -eq 0) { continue }

        $fqdn      = $tokens[0]
        $aliasList = @()
        if ($tokens.Count -gt 1) { $aliasList = @($tokens[1..($tokens.Count - 1)]) }

        $problem = Test-DnsName -Name $fqdn
        if ($problem) {
            [void] $rejected.Add((New-Object PSObject -Property @{
                Line   = $lineNo
                Input  = $raw.Trim()
                Reason = $problem
            }))
            continue
        }

        if ($seen.ContainsKey($fqdn)) {
            [void] $rejected.Add((New-Object PSObject -Property @{
                Line   = $lineNo
                Input  = $raw.Trim()
                Reason = "duplicate of $fqdn"
            }))
            continue
        }
        $seen[$fqdn] = $true

        # Validate each alias on its own. A bad alias is reported and dropped
        # rather than failing the host, since the primary name is still good.
        $goodAliases = @()
        foreach ($alias in $aliasList) {
            if ($alias -eq $fqdn) { continue }
            $aliasProblem = Test-DnsName -Name $alias
            if ($aliasProblem) {
                [void] $rejected.Add((New-Object PSObject -Property @{
                    Line   = $lineNo
                    Input  = $alias
                    Reason = "SAN alias dropped: $aliasProblem"
                }))
                continue
            }
            if ($goodAliases -notcontains $alias) { $goodAliases += $alias }
        }

        [void] $accepted.Add((New-Object PSObject -Property @{
            Fqdn      = $fqdn
            ShortName = ($fqdn -split '\.')[0]
            Aliases   = $goodAliases
            Original  = $raw.Trim()
        }))
    }

    return New-Object PSObject -Property @{
        Accepted = $accepted
        Rejected = $rejected
    }
}

$mode = $null
if ($HostFile)          { $mode = 'BULK' }
elseif ($ComputerName)  { $mode = 'SINGLE' }

if (-not $mode -and $NoPrompt) {
    throw 'With -NoPrompt you must pass -HostFile (bulk) or -ComputerName (single).'
}

if (-not $mode) {
    Write-Host ''
    Write-Host 'Issuance mode:'
    Write-Host '  [1] SINGLE - one hostname typed here'
    Write-Host '  [2] BULK   - a text file with one hostname per line'
    Write-Host ''
    while (-not $mode) {
        $answer = Read-Host 'Select 1 or 2, or Q to quit'
        switch -Regex ($answer) {
            '^1$'    { $mode = 'SINGLE' }
            '^2$'    { $mode = 'BULK' }
            '^[Qq]'  { Write-Host 'Cancelled.'; exit 2 }
            default  { Write-Host 'Not a valid selection.' -ForegroundColor Red }
        }
    }
}

$rawNames = @()

if ($mode -eq 'SINGLE') {
    if (-not $ComputerName) { $ComputerName = Read-Host 'Hostname or FQDN' }
    $rawNames = @($ComputerName)
} else {
    if (-not $HostFile) { $HostFile = Read-Host 'Full path to the hostname text file' }
    $HostFile = $HostFile.Trim().Trim('"').Trim("'")
    if (-not (Test-Path -LiteralPath $HostFile -PathType Leaf)) {
        throw "Hostname file not found: $HostFile"
    }
    $HostFile = (Resolve-Path -LiteralPath $HostFile).ProviderPath
    $rawNames = @(Get-Content -LiteralPath $HostFile)
    Write-Host ("Read {0} line(s) from {1}" -f $rawNames.Count, $HostFile)
}

Write-Step 'Normalizing host names...'
$normalized = Get-NormalizedHost -RawName $rawNames -DefaultDomain $Domain
$targets  = $normalized.Accepted
$rejected = $normalized.Rejected

if ($rejected.Count -gt 0) {
    Write-Host ''
    Write-Host ("{0} entr(y/ies) skipped:" -f $rejected.Count) -ForegroundColor DarkYellow
    foreach ($r in $rejected) {
        Write-Host ("  line {0,-5} {1,-40} {2}" -f $r.Line, $r.Input, $r.Reason) -ForegroundColor DarkYellow
    }
}

if ($targets.Count -eq 0) { throw 'No valid hostnames to process.' }

Write-Host ''
Write-Host ("{0} certificate(s) to issue:" -f $targets.Count) -ForegroundColor Green
$preview = $targets | Select-Object -First 15
foreach ($t in $preview) {
    Write-Host ("  {0}" -f $t.Fqdn)
    if (@($t.Aliases).Count -gt 0) {
        Write-Host ("      + SAN: {0}" -f (@($t.Aliases) -join ', ')) -ForegroundColor DarkGray
    }
}
if ($targets.Count -gt $preview.Count) {
    Write-Host ("  ... and {0} more" -f ($targets.Count - $preview.Count))
}

# ============================================================ subject and SAN

<#
    Everything here can be supplied on the command line. Anything NOT supplied
    is asked for, unless -NoPrompt is set (for scheduled or unattended runs),
    in which case the default is used. Values typed at a prompt are re-asked on
    a validation error; values passed as parameters throw, because an
    unattended run should fail loudly rather than quietly drop a field.
#>

$interactive = -not $NoPrompt

function Test-RdnValue {
    # Validated rather than escaped: commas, quotes and the other X.500 special
    # characters would need RFC 4514 escaping inside a certreq INF, and getting
    # that wrong yields a malformed subject on every certificate in the run.
    param([string] $Label, [string] $Value)
    if ($Value -match '[,"+;<>=\\#]') {
        return ("{0} cannot contain , `" + ; < > = \ or #" -f $Label)
    }
    if ($Value.Length -gt 64) {
        return ("{0} is longer than the 64-character X.520 limit" -f $Label)
    }
    return $null
}

function Read-RdnValue {
    param([string] $Label, [string] $Prompt)
    while ($true) {
        $v = (Read-Host ("  {0} (Enter to skip)" -f $Prompt)).Trim()
        if ($v -eq '') { return $null }
        $problem = Test-RdnValue -Label $Label -Value $v
        if (-not $problem) { return $v }
        Write-Host ("  {0}. Try again." -f $problem) -ForegroundColor Red
    }
}

function Resolve-SanName {
    # Lowercase, append the default domain to a bare name, validate.
    param([string] $Value, [string] $Suffix)
    $v = $Value.Trim().Trim('"').Trim("'").ToLower().TrimEnd('.')
    if ($v -eq '') { return $null }
    if (-not $v.Contains('.')) { $v = "$v.$Suffix" }
    return $v
}

# ---- subject fields -------------------------------------------------------------

$askedSubject = $false
if ($interactive -and
    -not $PSBoundParameters.ContainsKey('OrganizationalUnit') -and
    -not $PSBoundParameters.ContainsKey('Organization') -and
    -not $PSBoundParameters.ContainsKey('Locality') -and
    -not $PSBoundParameters.ContainsKey('State') -and
    -not $PSBoundParameters.ContainsKey('Country')) {

    Write-Host ''
    Write-Host 'Subject fields. CN is always the host FQDN; these are optional.' -ForegroundColor Cyan
    $answer = Read-Host 'Add OU / O / L / S / C to the subject? [y/N]'
    if ($answer -match '^[Yy]') {
        $askedSubject = $true
        $ouInput = Read-RdnValue -Label 'OU' -Prompt 'OU  organizational unit, e.g. IT'
        if ($ouInput) { $OrganizationalUnit = @($ouInput -split '[,;]' | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }
        $Organization = Read-RdnValue -Label 'O'  -Prompt 'O   organization, e.g. Example Corp'
        $Locality     = Read-RdnValue -Label 'L'  -Prompt 'L   city'
        $State        = Read-RdnValue -Label 'S'  -Prompt 'S   state or province'
        while ($true) {
            $c = (Read-Host '  C   country, two-letter code e.g. SG (Enter to skip)').Trim().ToUpper()
            if ($c -eq '') { $Country = $null; break }
            if ($c -match '^[A-Z]{2}$') { $Country = $c; break }
            Write-Host '  Must be exactly two letters. Try again.' -ForegroundColor Red
        }
    }
}

$rdnParts = @()
foreach ($ou in @($OrganizationalUnit)) {
    $v = "$ou".Trim()
    if ($v -eq '') { continue }
    $problem = Test-RdnValue -Label 'OU' -Value $v
    if ($problem) { throw "$problem (got '$v')" }
    $rdnParts += "OU=$v"
}
foreach ($pair in @(@('O', $Organization), @('L', $Locality), @('S', $State))) {
    $label = $pair[0]; $v = "$($pair[1])".Trim()
    if ($v -eq '') { continue }
    $problem = Test-RdnValue -Label $label -Value $v
    if ($problem) { throw "$problem (got '$v')" }
    $rdnParts += "$label=$v"
}
if ($Country) {
    $v = "$Country".Trim().ToUpper()
    if ($v -notmatch '^[A-Z]{2}$') { throw "Country must be a two-letter ISO code such as SG or US. Got '$Country'." }
    $rdnParts += "C=$v"
}
$subjectSuffix = if ($rdnParts.Count -gt 0) { ', ' + ($rdnParts -join ', ') } else { '' }

# ---- SAN ------------------------------------------------------------------------

if ($interactive) {
    Write-Host ''
    Write-Host 'Subject Alternative Names.' -ForegroundColor Cyan
    Write-Host ('  Already included: the FQDN{0}{1}' -f `
        $(if ($IncludeShortName) { ', the short name' } else { '' }),
        $(if (@($targets | Where-Object { @($_.Aliases).Count -gt 0 }).Count -gt 0) { ', and the per-host aliases from your list' } else { '' }))

    if (-not $PSBoundParameters.ContainsKey('AdditionalSan')) {
        $sanAnswer = (Read-Host '  Extra name(s) for EVERY host, comma separated (Enter for none)').Trim()
        if ($sanAnswer -ne '') { $AdditionalSan = @($sanAnswer) }
    }

    if (-not $PSBoundParameters.ContainsKey('IncludeIpAddress')) {
        $ipAnswer = Read-Host '  Add each host IPv4 address to the SAN? Needed if scanners target by IP [y/N]'
        if ($ipAnswer -match '^[Yy]') { $IncludeIpAddress = $true }
    }

    if (-not $PSBoundParameters.ContainsKey('IncludeShortName')) {
        $shortAnswer = Read-Host '  Include the short NetBIOS name in the SAN? [Y/n]'
        if ($shortAnswer -match '^[Nn]') { $IncludeShortName = $false }
    }
}

$globalSan = @()
foreach ($entry in @($AdditionalSan)) {
    if (-not $entry) { continue }
    foreach ($piece in ($entry -split '[,;\s]+')) {
        $v = Resolve-SanName -Value $piece -Suffix $Domain
        if (-not $v) { continue }
        $problem = Test-DnsName -Name $v
        if ($problem) {
            if ($interactive) {
                Write-Host ("  Dropping '{0}': {1}" -f $piece, $problem) -ForegroundColor Red
                continue
            }
            throw "-AdditionalSan value '$piece' is not a valid DNS name: $problem"
        }
        if ($globalSan -notcontains $v) { $globalSan += $v }
    }
}

# ---- cryptographic provider ------------------------------------------------------

<#
    Schema v1 and v2 templates are legacy-CSP only; a Key Storage Provider
    request against them fails with 0x80090017 NTE_PROV_TYPE_NOT_DEF during key
    generation, which is the error most people hit first. Schema v3+ templates
    can carry CT_FLAG_USE_LEGACY_PROVIDER (0x100) in msPKI-Private-Key-Flag,
    meaning the same thing. Anything else gets the KSP. Either way the per-host
    code retries with the other family if the first is rejected, so a wrong
    choice here costs one attempt rather than the whole run.
#>
$CT_FLAG_USE_LEGACY_PROVIDER = 0x00000100

if ($PSBoundParameters.ContainsKey('Provider') -and $Provider -ne 'Auto') {
    $providerMode = $Provider
    $providerReason = "forced by -Provider $Provider"
} elseif ($LegacyCsp) {
    $providerMode = 'CSP'
    $providerReason = 'forced by -LegacyCsp'
} elseif ($selected.SchemaVersion -ne $null -and $selected.SchemaVersion -le 2) {
    $providerMode = 'CSP'
    $providerReason = ("template schema v{0} supports legacy CSP only" -f $selected.SchemaVersion)
} elseif ($selected.KeyFlag -ne $null -and ($selected.KeyFlag -band $CT_FLAG_USE_LEGACY_PROVIDER)) {
    $providerMode = 'CSP'
    $providerReason = 'template sets Use Legacy Provider'
} elseif ($selected.SchemaVersion -eq $null) {
    $providerMode = 'CSP'
    $providerReason = 'template schema could not be read, defaulting to the wider-compatibility CSP'
} else {
    $providerMode = 'KSP'
    $providerReason = ("template schema v{0}" -f $selected.SchemaVersion)
}

if ($interactive -and
    -not $PSBoundParameters.ContainsKey('Provider') -and
    -not $PSBoundParameters.ContainsKey('LegacyCsp')) {

    Write-Host ''
    Write-Host 'Cryptographic provider.' -ForegroundColor Cyan
    Write-Host ("  Auto-detected: {0}  ({1})" -f $providerMode, $providerReason)
    Write-Host '  1  Legacy CSP  - Microsoft RSA SChannel Cryptographic Provider'
    Write-Host '  2  CNG KSP     - Microsoft Software Key Storage Provider'
    $pAnswer = (Read-Host ("  Choose 1 or 2, or Enter to keep {0}" -f $providerMode)).Trim()
    if     ($pAnswer -eq '1') { $providerMode = 'CSP'; $providerReason = 'chosen at the prompt' }
    elseif ($pAnswer -eq '2') { $providerMode = 'KSP'; $providerReason = 'chosen at the prompt' }
}

$providerLabel = if ($providerMode -eq 'CSP') {
    'Legacy CSP  (Microsoft RSA SChannel Cryptographic Provider)'
} else {
    'CNG KSP     (Microsoft Software Key Storage Provider)'
}

# ---- what this run will produce --------------------------------------------------

$sanDescription = @('FQDN')
if ($IncludeShortName) { $sanDescription += 'short name' }
if (@($targets | Where-Object { @($_.Aliases).Count -gt 0 }).Count -gt 0) { $sanDescription += 'per-host aliases' }
if ($globalSan.Count)  { $sanDescription += ('global: ' + ($globalSan -join ', ')) }
if ($IncludeIpAddress) { $sanDescription += 'resolved IPv4 address(es)' }

Write-Host ''
Write-Host ('-' * 62)
Write-Host ("  Template : {0}" -f $selected.CN)
Write-Host ("  Hosts    : {0}" -f $targets.Count)
Write-Host ("  Subject  : CN=<host>{0}" -f $subjectSuffix)
Write-Host ("  SAN      : {0}" -f ($sanDescription -join ', '))
Write-Host ("  Provider : {0}" -f $providerLabel)
Write-Host ("             {0}" -f $providerReason)
Write-Host ("  Key      : RSA {0}" -f $KeyLength)
Write-Host ("  Output   : {0}" -f $ExportRoot)
Write-Host ('-' * 62)

if ($NoPrompt) {
    Write-Host ''
    Write-Host ("-NoPrompt: proceeding with {0} certificate(s)." -f $targets.Count) -ForegroundColor Cyan
} else {
    Write-Host ''
    $confirm = Read-Host ("Issue {0} certificate(s)? [y/N]" -f $targets.Count)
    if ($confirm -notmatch '^[Yy]') { Write-Host 'Cancelled.'; exit 2 }
}

# ============================================================ password

if (-not $Password -and $NoPrompt) {
    throw 'With -NoPrompt you must pass -Password as a SecureString.'
}

if (-not $Password) {
    Write-Host ''
    Write-Host 'This password protects every exported PFX.' -ForegroundColor Cyan
    while (-not $Password) {
        $p1 = Read-Host 'PFX password' -AsSecureString
        $p2 = Read-Host 'Confirm password' -AsSecureString
        $s1 = ConvertFrom-SecureStringPlain $p1
        $s2 = ConvertFrom-SecureStringPlain $p2
        if ([string]::IsNullOrEmpty($s1)) {
            Write-Host 'Password cannot be empty.' -ForegroundColor Red
        } elseif ($s1 -ne $s2) {
            Write-Host 'Passwords do not match.' -ForegroundColor Red
        } elseif ($s1.Length -lt 8) {
            Write-Host 'Use at least 8 characters.' -ForegroundColor Red
        } else {
            $Password = $p1
        }
        $s1 = $null; $s2 = $null
    }
}
$pfxPlain = ConvertFrom-SecureStringPlain $Password

# ============================================================ output + chain

if (-not $OutputPath) {
    $OutputPath = Join-Path $ExportRoot ("HostCerts_{0:yyyyMMdd_HHmmss}" -f (Get-Date))
}
try {
    $null = New-Item -Path $OutputPath -ItemType Directory -Force
} catch {
    throw "Could not create the output folder '$OutputPath': $($_.Exception.Message)"
}
$OutputPath = (Resolve-Path -LiteralPath $OutputPath).ProviderPath

$workRoot = Join-Path $env:TEMP ("cagen_{0}" -f ([guid]::NewGuid().ToString('N')))
$null = New-Item -Path $workRoot -ItemType Directory -Force

Write-Host ''
Write-Host ("Output folder  : {0}" -f $OutputPath)
Write-Host ("Key length     : {0}" -f $KeyLength)

# Export the CA chain once, reused in every ZIP.
Write-Step 'Exporting the CA chain...'
$chainDir  = Join-Path $workRoot 'chain'
$null = New-Item -Path $chainDir -ItemType Directory -Force
$chainFile = Join-Path $chainDir 'ca-chain.p7b'
$chainPem  = Join-Path $chainDir 'ca-chain.pem'
$chainCerts = @()

try {
    $caCertOut = & certutil.exe -config "$caConfig" -ca.chain "$chainFile" 2>&1
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $chainFile)) {
        throw ($caCertOut -join ' ')
    }
    $chainCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
    $chainCollection.Import($chainFile)
    foreach ($c in $chainCollection) { $chainCerts += $c }

    # Clean PEM: no text outside BEGIN/END blocks, which some importers
    # (Nessus custom CA, older Java keytool, some appliances) reject.
    function ConvertTo-Pem {
        param($Certificate)
        $b64 = [Convert]::ToBase64String($Certificate.RawData, 'InsertLineBreaks')
        return "-----BEGIN CERTIFICATE-----`r`n$b64`r`n-----END CERTIFICATE-----`r`n"
    }

    # Order leaf-side first: intermediates, then root.
    $roots = @($chainCerts | Where-Object { $_.Subject -eq $_.Issuer })
    $intermediates = @($chainCerts | Where-Object { $_.Subject -ne $_.Issuer })

    $all = ''
    foreach ($c in $intermediates) { $all += (ConvertTo-Pem $c) }
    foreach ($c in $roots)         { $all += (ConvertTo-Pem $c) }
    Set-Content -LiteralPath $chainPem -Value $all -Encoding ASCII

    if ($roots.Count -gt 0) {
        $rootText = ''
        foreach ($c in $roots) { $rootText += (ConvertTo-Pem $c) }
        Set-Content -LiteralPath (Join-Path $chainDir 'ca-root.pem') -Value $rootText -Encoding ASCII
    }
    if ($intermediates.Count -gt 0) {
        $intText = ''
        foreach ($c in $intermediates) { $intText += (ConvertTo-Pem $c) }
        Set-Content -LiteralPath (Join-Path $chainDir 'ca-intermediate.pem') -Value $intText -Encoding ASCII
    }

    foreach ($c in $intermediates) { Write-Host ("  intermediate : {0}" -f $c.Subject) }
    foreach ($c in $roots)         { Write-Host ("  root         : {0}" -f $c.Subject) }
    Write-Host ("{0} CA certificate(s) in the chain." -f $chainCerts.Count) -ForegroundColor Green
} catch {
    Write-Warning ("Could not export the CA chain: {0}" -f $_.Exception.Message)
    Write-Warning 'PFX files will still be built; chain certificates will be added from the local store instead.'
}

# ============================================================ per-host issuance

function Remove-CertificateAndKey {
    <# Removes the cert from LocalMachine\My and deletes the orphaned key file. #>
    param([string] $Thumbprint)

    $container = $null
    try {
        $storeOut = & certutil.exe -store My $Thumbprint 2>&1
        foreach ($line in $storeOut) {
            if ($line -match 'Unique container name:\s*(\S+)') { $container = $matches[1]; break }
        }
    } catch { }

    try { $null = & certutil.exe -delstore My $Thumbprint 2>&1 } catch { }

    if ($container) {
        foreach ($dir in @('Microsoft\Crypto\RSA\MachineKeys', 'Microsoft\Crypto\Keys')) {
            $keyFile = Join-Path $env:ProgramData (Join-Path $dir $container)
            if (Test-Path -LiteralPath $keyFile) {
                try { Remove-Item -LiteralPath $keyFile -Force } catch { }
            }
        }
    }
}

function New-HostCertificate {
    param(
        [PSObject] $Target,
        [string]   $TemplateCn,
        [string]   $CaConfigString,
        [int]      $Bits,
        [bool]     $AddShortName,
        [string[]] $ExtraSan,
        [string]   $SubjectSuffix,
        [bool]     $AddIpAddress,
        [string]   $ProviderMode,
        [string]   $WorkDirectory,
        [string]   $Destination,
        [string]   $PfxPassword,
        [object[]] $CaChain,
        [string]   $ChainPemFile,
        [bool]     $Retain
    )

    $fqdn    = $Target.Fqdn
    $hostDir = Join-Path $WorkDirectory $fqdn
    $null = New-Item -Path $hostDir -ItemType Directory -Force

    $infFile = Join-Path $hostDir 'request.inf'
    $reqFile = Join-Path $hostDir 'request.req'
    $cerFile = Join-Path $hostDir ("{0}.cer" -f $fqdn)

    $result = New-Object PSObject -Property @{
        Host       = $fqdn
        Original   = $Target.Original
        Status     = 'Failed'
        Thumbprint = ''
        Serial     = ''
        NotAfter   = ''
        RequestId  = ''
        Provider   = ''
        SubjectMismatch = $false
        ZipFile    = ''
        Detail     = ''
    }

    $thumbprint = $null

    try {
        # ---- SAN list
        # SAN order matters a little: the primary FQDN first, since some older
        # clients display or match on the first entry.
        $sanNames = @($fqdn)
        if ($AddShortName -and $Target.ShortName -ne $fqdn) {
            $sanNames += $Target.ShortName
        }
        foreach ($alias in @($Target.Aliases)) {
            if ($alias -and ($sanNames -notcontains $alias)) { $sanNames += $alias }
        }
        foreach ($alias in @($ExtraSan)) {
            if ($alias -and ($sanNames -notcontains $alias)) { $sanNames += $alias }
        }

        $sanLines = @()
        foreach ($n in $sanNames) { $sanLines += "dns=$n" }
        if ($AddIpAddress) {
            try {
                $addresses = [System.Net.Dns]::GetHostAddresses($fqdn) |
                    Where-Object { $_.AddressFamily -eq 'InterNetwork' } |
                    ForEach-Object { $_.IPAddressToString } |
                    Select-Object -Unique
                foreach ($ip in $addresses) { $sanLines += "ipaddress=$ip" }
                if (-not $addresses) {
                    Write-Host ("        note    {0} has no IPv4 record; issuing without an IP SAN" -f $fqdn) -ForegroundColor DarkYellow
                }
            } catch {
                Write-Host ("        note    {0} did not resolve in DNS; issuing without an IP SAN" -f $fqdn) -ForegroundColor DarkYellow
            }
        }

        $sanBlock = New-Object System.Text.StringBuilder
        [void] $sanBlock.AppendLine('2.5.29.17 = "{text}"')
        for ($i = 0; $i -lt $sanLines.Count; $i++) {
            $suffix = if ($i -lt ($sanLines.Count - 1)) { '&' } else { '' }
            [void] $sanBlock.AppendLine(('_continue_ = "{0}{1}"' -f $sanLines[$i], $suffix))
        }

        # ---- provider block
        # ProviderType must be stated explicitly. Left out, certreq assumes
        # type 1 (PROV_RSA_FULL), which the Key Storage Provider does not
        # implement, and key generation dies with 0x80090017
        # NTE_PROV_TYPE_NOT_DEF before anything reaches the CA.
        function Get-ProviderBlock {
            param([string] $Mode)
            if ($Mode -eq 'CSP') {
                return @'
ProviderName = "Microsoft RSA SChannel Cryptographic Provider"
ProviderType = 12
KeySpec = 1
'@
            }
            return @'
ProviderName = "Microsoft Software Key Storage Provider"
ProviderType = 0
KeyAlgorithm = RSA
KeySpec = 0
'@
        }

        function New-RequestInf {
            param([string] $Mode)
            $providerBlock = Get-ProviderBlock -Mode $Mode
            return @"
[Version]
Signature="`$Windows NT`$"

[NewRequest]
Subject = "CN=$fqdn$SubjectSuffix"
FriendlyName = "$fqdn"
KeyLength = $Bits
Exportable = TRUE
MachineKeySet = TRUE
RequestType = PKCS10
HashAlgorithm = SHA256
KeyUsage = 0xa0
SMIME = FALSE
UseExistingKeySet = FALSE
$providerBlock

[Strings]
szOID_SUBJECT_ALT_NAME2 = "2.5.29.17"
szOID_ENHANCED_KEY_USAGE = "2.5.29.37"
szOID_PKIX_KP_SERVER_AUTH = "1.3.6.1.5.5.7.3.1"
szOID_PKIX_KP_CLIENT_AUTH = "1.3.6.1.5.5.7.3.2"

[Extensions]
$($sanBlock.ToString())
[RequestAttributes]
CertificateTemplate = $TemplateCn
"@
        }

        # ---- 1. generate key + CSR, falling back to the other provider family
        $modeOrder = if ($ProviderMode -eq 'CSP') { @('CSP', 'KSP') } else { @('KSP', 'CSP') }
        $genOk = $false
        $genErrors = @()

        foreach ($mode in $modeOrder) {
            Set-Content -LiteralPath $infFile -Value (New-RequestInf -Mode $mode) -Encoding ASCII
            if (Test-Path -LiteralPath $reqFile) { Remove-Item -LiteralPath $reqFile -Force }

            $out = & certreq.exe -new -f -q "$infFile" "$reqFile" 2>&1
            $outText = (($out | Where-Object { $_ -match '\S' }) -join ' | ')

            if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $reqFile)) {
                $result.Provider = $mode
                $genOk = $true
                if ($mode -ne $modeOrder[0]) {
                    Write-Host ("        note    first provider rejected the request; succeeded with {0}" -f $mode) -ForegroundColor DarkYellow
                }
                break
            }

            $genErrors += ("{0}: {1}" -f $mode, $outText)

            # Only a provider-family mismatch is worth retrying. Anything else
            # (permissions, missing template, bad key length) will fail the same
            # way twice, so stop and report it.
            $providerMismatch = ($outText -match '0x80090017') -or
                                ($outText -match 'NTE_PROV_TYPE_NOT_DEF') -or
                                ($outText -match '0x8009000f') -or
                                ($outText -match 'provider type')
            if (-not $providerMismatch) { break }
        }

        if (-not $genOk) {
            throw ("key generation failed: " + ($genErrors -join ' || '))
        }

        # ---- 2. submit to the CA
        $out = & certreq.exe -submit -q -config "$CaConfigString" "$reqFile" "$cerFile" 2>&1
        $outText = ($out | Where-Object { $_ -match '\S' }) -join ' | '

        if ($outText -match 'RequestId:\s*(\d+)') { $result.RequestId = $matches[1] }

        if (-not (Test-Path -LiteralPath $cerFile)) {
            if ($outText -match 'Taken Under Submission|pending') {
                $result.Status = 'Pending'
                $result.Detail = "Request $($result.RequestId) is awaiting manager approval. Approve it in the CA console, then run: certreq -retrieve -config `"$CaConfigString`" $($result.RequestId) $fqdn.cer"
                return $result
            }
            if ($outText -match 'Denied|denied') {
                throw ("the CA denied the request: " + $outText)
            }
            throw ("submission produced no certificate: " + $outText)
        }

        # ---- 3. accept: binds the issued cert to the pending private key
        $out = & certreq.exe -accept -q -machine "$cerFile" 2>&1
        if ($LASTEXITCODE -ne 0) {
            throw ("could not install the issued certificate: " + (($out | Where-Object { $_ -match '\S' }) -join ' | '))
        }

        # ---- 4. locate it in the store, with the private key attached
        $issued = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
        $issued.Import($cerFile)
        $thumbprint = $issued.Thumbprint.ToUpper()

        $store = New-Object System.Security.Cryptography.X509Certificates.X509Store('My', 'LocalMachine')
        $store.Open('ReadOnly')
        try {
            $found = $store.Certificates | Where-Object { $_.Thumbprint -eq $thumbprint } | Select-Object -First 1
            if (-not $found)                { throw 'the issued certificate is not in LocalMachine\My after accept' }
            if (-not $found.HasPrivateKey)  { throw 'the issued certificate has no private key attached' }
            $leaf = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($found)
        } finally {
            $store.Close()
        }

        $result.Thumbprint = $thumbprint
        $result.Serial     = $leaf.SerialNumber
        $result.NotAfter   = $leaf.NotAfter.ToString('yyyy-MM-dd')

        # ---- 4b. verify the CA honoured the subject we asked for
        # If the template is set to "Build from this Active Directory
        # information", ADCS discards the requested CN/OU/SAN and substitutes
        # the requester's AD object. certreq reports success regardless, so
        # this is the only place it can be caught.
        $issuedCn = $null
        if ($leaf.Subject -match '(?:^|,\s*)CN=([^,]+)') { $issuedCn = $matches[1].Trim().ToLower() }

        $issuedDns = @()
        foreach ($ext in $leaf.Extensions) {
            if ($ext.Oid.Value -eq '2.5.29.17') {
                foreach ($line in ($ext.Format($true) -split "`r?`n")) {
                    if ($line -match 'DNS Name=([^,\s]+)') { $issuedDns += $matches[1].Trim().ToLower() }
                }
            }
        }

        $subjectProblems = @()
        if (-not $leaf.Subject -or $leaf.Subject.Trim() -eq '') {
            $subjectProblems += 'the issued certificate has an EMPTY subject'
        } elseif (-not $issuedCn) {
            $subjectProblems += ("the issued subject has no CN (got '{0}')" -f $leaf.Subject)
        } elseif ($issuedCn -ne $fqdn) {
            $subjectProblems += ("the issued CN is '{0}', expected '{1}'" -f $issuedCn, $fqdn)
        }
        if ($issuedDns -notcontains $fqdn) {
            $subjectProblems += ("the SAN does not contain {0} (SAN has: {1})" -f $fqdn, $(if ($issuedDns) { $issuedDns -join ', ' } else { 'nothing' }))
        }
        if ($SubjectSuffix -and $SubjectSuffix -match 'OU=' -and $leaf.Subject -notmatch 'OU=') {
            $subjectProblems += 'the requested OU was dropped'
        }

        if ($subjectProblems.Count -gt 0) {
            $result.SubjectMismatch = $true
            throw ("CA did not honour the requested subject: {0}. Serial {1} was issued but is unusable and has been discarded; revoke it with: certutil -revoke {1} 4" -f ($subjectProblems -join '; '), $leaf.SerialNumber)
        }

        # ---- 5. build the full-chain PFX
        $bundle = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
        [void] $bundle.Add($leaf)

        $chainToUse = @()
        if ($CaChain -and $CaChain.Count -gt 0) {
            $chainToUse = $CaChain
        } else {
            $builder = New-Object System.Security.Cryptography.X509Certificates.X509Chain
            $builder.ChainPolicy.RevocationMode = 'NoCheck'
            if ($builder.Build($leaf)) {
                foreach ($element in $builder.ChainElements) {
                    if ($element.Certificate.Thumbprint -ne $thumbprint) {
                        $chainToUse += $element.Certificate
                    }
                }
            }
        }
        foreach ($c in $chainToUse) {
            if ($c.Thumbprint -ne $thumbprint) { [void] $bundle.Add($c) }
        }

        $pfxBytes = $bundle.Export('Pkcs12', $PfxPassword)
        if (-not $pfxBytes -or $pfxBytes.Length -eq 0) { throw 'PFX export returned no data' }

        # ---- 6. stage the ZIP contents
        $stage = Join-Path $hostDir 'stage'
        $null = New-Item -Path $stage -ItemType Directory -Force

        [System.IO.File]::WriteAllBytes((Join-Path $stage ("{0}.pfx" -f $fqdn)), $pfxBytes)
        Copy-Item -LiteralPath $cerFile -Destination (Join-Path $stage ("{0}.cer" -f $fqdn)) -Force
        if ($ChainPemFile -and (Test-Path -LiteralPath $ChainPemFile)) {
            $chainFolder = Split-Path -Parent $ChainPemFile
            Get-ChildItem -LiteralPath $chainFolder -File |
                Where-Object { $_.Extension -in @('.pem', '.p7b') } |
                ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $stage $_.Name) -Force }
        }

        $info = @"
Host             : $fqdn
Subject          : $($leaf.Subject)
Issuer           : $($leaf.Issuer)
Serial           : $($leaf.SerialNumber)
Thumbprint       : $thumbprint
Valid from       : $($leaf.NotBefore)
Expires          : $($leaf.NotAfter)
Template         : $TemplateCn
Key length       : $Bits
SAN              : $($sanLines -join ', ')
Subject verified : CN and SAN match the request
Chain included   : $($chainToUse.Count) CA certificate(s)
Issued by        : $CaConfigString
Issued on        : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')

The .pfx is protected by the password supplied at issuance time.
The .zip itself is NOT encrypted.

Files:
  $fqdn.pfx           certificate + private key + chain (password protected)
  $fqdn.cer           issued certificate only, DER
  ca-chain.pem          intermediates then root, clean PEM
  ca-root.pem           root CA only - upload this to Nessus as a custom CA
  ca-intermediate.pem   issuing/intermediate CA(s), if any
  ca-chain.p7b          same chain in PKCS#7, for Windows import

Vulnerability scanners (Nessus, Qualys, Rapid7) report "certificate cannot be
trusted" until THEIR trust store contains your internal root. Upload
ca-root.pem (and ca-intermediate.pem if present) to the scanner. This is a
scanner configuration step, not a certificate defect.

To install on the target host:
  Install-RdpCertificate.bat $fqdn.pfx
or manually:
  certutil -p <password> -importpfx My "$fqdn.pfx"
"@
        Set-Content -LiteralPath (Join-Path $stage 'cert-info.txt') -Value $info -Encoding ASCII

        # ---- 7. zip
        $zipPath = Join-Path $Destination ("{0}.zip" -f $fqdn)
        if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
        [System.IO.Compression.ZipFile]::CreateFromDirectory(
            $stage, $zipPath,
            [System.IO.Compression.CompressionLevel]::Optimal, $false)

        if (-not (Test-Path -LiteralPath $zipPath)) { throw 'ZIP creation produced no file' }

        $result.ZipFile = $zipPath
        $result.Status  = 'Issued'
        $result.Detail  = ''
        return $result
    } catch {
        $result.Status = if ($result.Status -eq 'Pending') { 'Pending' } else { 'Failed' }
        if (-not $result.Detail) { $result.Detail = $_.Exception.Message }
        return $result
    } finally {
        # Never leave another host's private key sitting on the CA.
        if ($thumbprint -and -not $Retain) {
            Remove-CertificateAndKey -Thumbprint $thumbprint
        }
        # Shred the staged PFX and CSR material.
        try { Remove-Item -LiteralPath $hostDir -Recurse -Force -ErrorAction SilentlyContinue } catch { }
    }
}

Write-Banner ("Issuing {0} certificate(s)" -f $targets.Count)

$results = New-Object System.Collections.ArrayList
$index = 0

foreach ($target in $targets) {
    $index++
    Write-Host ''
    Write-Host ("[{0}/{1}] {2}" -f $index, $targets.Count, $target.Fqdn) -ForegroundColor White

    $r = New-HostCertificate -Target $target `
                             -TemplateCn $selected.CN `
                             -CaConfigString $caConfig `
                             -Bits $KeyLength `
                             -AddShortName ([bool] $IncludeShortName) `
                             -ExtraSan $globalSan `
                             -SubjectSuffix $subjectSuffix `
                             -AddIpAddress ([bool] $IncludeIpAddress) `
                             -ProviderMode $providerMode `
                             -WorkDirectory $workRoot `
                             -Destination $OutputPath `
                             -PfxPassword $pfxPlain `
                             -CaChain $chainCerts `
                             -ChainPemFile $chainPem `
                             -Retain ([bool] $KeepInStore)

    [void] $results.Add($r)

    if ($r.SubjectMismatch) {
        Write-Host ("        FAILED  {0}" -f $r.Detail) -ForegroundColor Red
        Write-Host ''
        Write-Host ('!' * 62) -ForegroundColor Red
        Write-Host '  STOPPING: the CA is overwriting the requested subject.' -ForegroundColor Red
        Write-Host '  Every remaining host would come out the same way.' -ForegroundColor Red
        Write-Host ''
        Write-Host ("  Fix template '{0}':" -f $selected.CN) -ForegroundColor Yellow
        Write-Host '    CA console > Certificate Templates > right-click > Properties' -ForegroundColor Yellow
        Write-Host '    Subject Name tab > select "Supply in the request"' -ForegroundColor Yellow
        Write-Host '    (for a built-in template, Duplicate it first - built-ins are read-only)' -ForegroundColor Yellow
        Write-Host '    Then publish the duplicate: Certificate Templates > New > Template to Issue' -ForegroundColor Yellow
        Write-Host ('!' * 62) -ForegroundColor Red

        $remaining = $targets | Select-Object -Skip $index
        foreach ($skip in $remaining) {
            [void] $results.Add((New-Object PSObject -Property @{
                Host = $skip.Fqdn; Original = $skip.Original; Status = 'Skipped'
                Provider = ''; Serial = ''; Thumbprint = ''; NotAfter = ''; RequestId = ''; ZipFile = ''
                SubjectMismatch = $false
                Detail = 'not attempted: template overwrites the requested subject'
            }))
        }
        break
    }

    switch ($r.Status) {
        'Issued'  { Write-Host ("        OK      serial {0}, expires {1}" -f $r.Serial, $r.NotAfter) -ForegroundColor Green }
        'Pending' { Write-Host ("        PENDING {0}" -f $r.Detail) -ForegroundColor DarkYellow }
        default   { Write-Host ("        FAILED  {0}" -f $r.Detail) -ForegroundColor Red }
    }
}

# ============================================================ wrap up

$pfxPlain = $null
[System.GC]::Collect()

try { Remove-Item -LiteralPath $workRoot -Recurse -Force -ErrorAction SilentlyContinue } catch { }

$issued  = @($results | Where-Object { $_.Status -eq 'Issued' })
$pending = @($results | Where-Object { $_.Status -eq 'Pending' })
$failed  = @($results | Where-Object { $_.Status -eq 'Failed' })
$skippedHosts = @($results | Where-Object { $_.Status -eq 'Skipped' })

$csvPath = Join-Path $OutputPath ("issuance-log_{0:yyyyMMdd_HHmmss}.csv" -f (Get-Date))
$results | Select-Object Host, Original, Status, Provider, Serial, Thumbprint, NotAfter, RequestId, ZipFile, Detail |
    Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8

Write-Banner 'Summary'
Write-Host ("Issued   : {0}" -f $issued.Count)  -ForegroundColor Green
if ($pending.Count) { Write-Host ("Pending  : {0}" -f $pending.Count) -ForegroundColor DarkYellow }
if ($failed.Count)  { Write-Host ("Failed   : {0}" -f $failed.Count)  -ForegroundColor Red }
if ($skippedHosts.Count) { Write-Host ("Not run  : {0} (stopped after a subject mismatch)" -f $skippedHosts.Count) -ForegroundColor Red }
if ($rejected.Count){ Write-Host ("Skipped  : {0} (invalid or duplicate input)" -f $rejected.Count) -ForegroundColor DarkYellow }

if ($failed.Count -gt 0) {
    Write-Host ''
    Write-Host 'Failures:' -ForegroundColor Red
    foreach ($f in $failed) { Write-Host ("  {0,-45} {1}" -f $f.Host, $f.Detail) -ForegroundColor Red }
}

if ($pending.Count -gt 0) {
    Write-Host ''
    Write-Host 'Awaiting CA manager approval:' -ForegroundColor DarkYellow
    foreach ($p in $pending) { Write-Host ("  {0,-45} request {1}" -f $p.Host, $p.RequestId) -ForegroundColor DarkYellow }
}

Write-Host ''
Write-Host ("ZIP files : {0}" -f $OutputPath)
Write-Host ("Log       : {0}" -f $csvPath)
Write-Host ''
Write-Host 'Each ZIP holds the .pfx (password protected), the issued .cer, the CA chain, and cert-info.txt.' -ForegroundColor Cyan
Write-Host 'The ZIP container itself is not encrypted, so move them over a trusted channel.' -ForegroundColor Cyan

if ($failed.Count -gt 0 -or $skippedHosts.Count -gt 0) { exit 1 }
exit 0
