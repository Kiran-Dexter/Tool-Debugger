<#
.SYNOPSIS
    Builds a PFX on the machine that generated the CSR, by pairing the signed
    certificate with the private key that machine already holds.

.DESCRIPTION
    Run this ON THE REQUESTER'S MACHINE, elevated - not on the CA. The CA cannot
    produce a PFX from a CSR because it never receives the private key.

    Handles the three situations that actually occur:

      1. PENDING REQUEST IN THE WINDOWS STORE
         The machine created the CSR with certreq or the IIS console, so Windows
         is holding the key against a pending request. The script runs
         certreq -accept to marry the issued certificate to that key, then
         exports a PFX.

      2. CERTIFICATE ALREADY INSTALLED WITH ITS KEY
         Someone already accepted the certificate. The script finds it by
         thumbprint or subject and exports it.

      3. A SEPARATE PEM KEY FILE
         The CSR came from OpenSSL, so there is a .key file next to it. Needs
         openssl.exe, which the script locates or you point at with -OpenSslPath.
         Without OpenSSL the script prints the exact command to run elsewhere.

    The chain is included in the PFX in every case, so the result installs
    cleanly without hunting for intermediates afterwards.

    Compatible with Windows Server 2012 onward (PowerShell 3.0+, .NET 4.5+).

.PARAMETER CertificatePath
    The signed certificate from the CA: .cer or .pem.

.PARAMETER KeyPath
    A PEM private key file, for case 3. Omit for cases 1 and 2.

.PARAMETER ChainPath
    ca-chain.pem from the CA's zip. Optional: without it the chain is built from
    this machine's own store.

.PARAMETER PfxPath
    Where to write the PFX. Defaults to the certificate's name with .pfx.

.PARAMETER Password
    PFX password as a SecureString. Prompted for if omitted.

.PARAMETER Thumbprint
    For case 2, the certificate to export, when several match the subject.

.PARAMETER OpenSslPath
    Full path to openssl.exe, if it is not on PATH.

.PARAMETER Force
    Overwrite an existing PFX.

.EXAMPLE
    .\Convert-ToPfx.ps1 -CertificatePath web01.corp.example.com.cer

.EXAMPLE
    .\Convert-ToPfx.ps1 -CertificatePath web01.pem -KeyPath web01.key -ChainPath ca-chain.pem
#>
[CmdletBinding()]
param(
    [string] $CertificatePath,
    [string] $KeyPath,
    [string] $ChainPath,
    [string] $PfxPath,
    [System.Security.SecureString] $Password,
    [string] $Thumbprint,
    [string] $OpenSslPath,
    [switch] $Force
)

$ErrorActionPreference = 'Stop'

function Write-Step {
    param([int] $Number, [string] $Message)
    Write-Host ''
    Write-Host ("[{0}] {1}" -f $Number, $Message) -ForegroundColor Yellow
}

function ConvertFrom-SecureStringPlain {
    param([System.Security.SecureString] $Secure)
    $ptr = [System.Runtime.InteropServices.Marshal]::SecureStringToGlobalAllocUnicode($Secure)
    try   { [System.Runtime.InteropServices.Marshal]::PtrToStringUni($ptr) }
    finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeGlobalAllocUnicode($ptr) }
}

Write-Host ''
Write-Host '==============================================================' -ForegroundColor DarkCyan
Write-Host '  Build a PFX from a signed certificate + local private key'   -ForegroundColor Cyan
Write-Host '==============================================================' -ForegroundColor DarkCyan

# ---------------------------------------------------------------- preconditions

$identity  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this elevated (Run as Administrator). The machine key store needs it.'
}
if ($PSVersionTable.PSVersion.Major -lt 3) {
    throw "PowerShell 3.0 or later is required. Found $($PSVersionTable.PSVersion)."
}

if (-not $CertificatePath) { $CertificatePath = Read-Host 'Path to the signed certificate (.cer or .pem)' }
$CertificatePath = $CertificatePath.Trim().Trim('"').Trim("'")
if (-not (Test-Path -LiteralPath $CertificatePath -PathType Leaf)) {
    throw "Certificate not found: $CertificatePath"
}
$CertificatePath = (Resolve-Path -LiteralPath $CertificatePath).ProviderPath

foreach ($optional in @('KeyPath', 'ChainPath')) {
    $v = (Get-Variable -Name $optional -ValueOnly)
    if ($v) {
        $v = $v.Trim().Trim('"').Trim("'")
        if (-not (Test-Path -LiteralPath $v -PathType Leaf)) { throw "$optional not found: $v" }
        Set-Variable -Name $optional -Value ((Resolve-Path -LiteralPath $v).ProviderPath)
    }
}

# ---- read the certificate so we can report what we are working with
$incoming = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
try {
    $incoming.Import($CertificatePath)
} catch {
    throw "Could not read '$CertificatePath' as a certificate. If this is still a CSR, you need the signed certificate from the CA instead. ($($_.Exception.Message))"
}

$certThumbprint = $incoming.Thumbprint.ToUpper()
Write-Host ''
Write-Host ("Subject    : {0}" -f $incoming.Subject)
Write-Host ("Issuer     : {0}" -f $incoming.Issuer)
Write-Host ("Serial     : {0}" -f $incoming.SerialNumber)
Write-Host ("Thumbprint : {0}" -f $certThumbprint)
Write-Host ("Expires    : {0}" -f $incoming.NotAfter)

if (-not $PfxPath) {
    $dir  = [System.IO.Path]::GetDirectoryName($CertificatePath)
    $stem = [System.IO.Path]::GetFileNameWithoutExtension($CertificatePath)
    $PfxPath = Join-Path $dir ("{0}.pfx" -f $stem)
}
if ((Test-Path -LiteralPath $PfxPath) -and -not $Force) {
    throw "PFX already exists: $PfxPath  (use -Force to overwrite)"
}

# ---------------------------------------------------------------- which route

$route = $null

if ($KeyPath) {
    $route = 'OpenSsl'
} else {
    # Is the certificate, or a pending request for it, already in this store?
    $store = New-Object System.Security.Cryptography.X509Certificates.X509Store('My', 'LocalMachine')
    $store.Open('ReadOnly')
    try {
        $already = $store.Certificates | Where-Object { $_.Thumbprint -eq $certThumbprint } | Select-Object -First 1
    } finally {
        $store.Close()
    }

    if ($already -and $already.HasPrivateKey) {
        $route = 'AlreadyInstalled'
    } else {
        $route = 'AcceptPending'
    }
}

Write-Host ''
switch ($route) {
    'AcceptPending'    { Write-Host 'Route: accept the pending request held by this machine.' -ForegroundColor Cyan }
    'AlreadyInstalled' { Write-Host 'Route: the certificate is already installed with its key; exporting.' -ForegroundColor Cyan }
    'OpenSsl'          { Write-Host 'Route: pair the certificate with the PEM key file using OpenSSL.' -ForegroundColor Cyan }
}

# ---------------------------------------------------------------- password

if (-not $Password) {
    Write-Host ''
    while (-not $Password) {
        $p1 = Read-Host 'PFX password' -AsSecureString
        $p2 = Read-Host 'Confirm password' -AsSecureString
        $s1 = ConvertFrom-SecureStringPlain $p1
        $s2 = ConvertFrom-SecureStringPlain $p2
        if ([string]::IsNullOrEmpty($s1))   { Write-Host 'Password cannot be empty.' -ForegroundColor Red }
        elseif ($s1 -ne $s2)                { Write-Host 'Passwords do not match.' -ForegroundColor Red }
        elseif ($s1.Length -lt 8)           { Write-Host 'Use at least 8 characters.' -ForegroundColor Red }
        else                                { $Password = $p1 }
        $s1 = $null; $s2 = $null
    }
}
$pfxPlain = ConvertFrom-SecureStringPlain $Password

# ---------------------------------------------------------------- chain

function Get-ChainCertificate {
    param([string] $PemPath, $Leaf)

    $certs = @()

    if ($PemPath) {
        try {
            $collection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
            $collection.Import($PemPath)
            foreach ($c in $collection) { $certs += $c }
            Write-Host ("Chain from file : {0} certificate(s)" -f $certs.Count)
            return $certs
        } catch {
            Write-Warning ("Could not read the chain file, falling back to this machine's store: {0}" -f $_.Exception.Message)
        }
    }

    $builder = New-Object System.Security.Cryptography.X509Certificates.X509Chain
    $builder.ChainPolicy.RevocationMode = 'NoCheck'
    if ($builder.Build($Leaf)) {
        foreach ($element in $builder.ChainElements) {
            if ($element.Certificate.Thumbprint -ne $Leaf.Thumbprint) { $certs += $element.Certificate }
        }
        Write-Host ("Chain from store: {0} certificate(s)" -f $certs.Count)
    } else {
        Write-Warning 'The chain could not be built on this machine. The PFX will carry the certificate alone.'
        Write-Warning 'Pass -ChainPath ca-chain.pem from the CA zip to include it.'
    }
    return $certs
}

# ---------------------------------------------------------------- do the work

switch ($route) {

    'AcceptPending' {
        Write-Step 1 'Accepting the issued certificate against the pending request...'

        $out = & certreq.exe -accept -machine "$CertificatePath" 2>&1
        $outText = (($out | Where-Object { $_ -match '\S' }) -join ' | ')

        if ($LASTEXITCODE -ne 0) {
            Write-Host ''
            Write-Host $outText -ForegroundColor DarkGray
            Write-Host ''
            Write-Host 'certreq -accept failed. The usual causes:' -ForegroundColor Red
            Write-Host '  - this is not the machine that generated the CSR, so the key is not here' -ForegroundColor DarkYellow
            Write-Host '  - the pending request was deleted (check certlm.msc > Certificate Enrollment Requests)' -ForegroundColor DarkYellow
            Write-Host '  - the CSR was made with OpenSSL, not certreq; use -KeyPath with the .key file' -ForegroundColor DarkYellow
            throw 'Could not accept the certificate.'
        }

        Write-Step 2 'Locating the certificate and its private key...'
        $store = New-Object System.Security.Cryptography.X509Certificates.X509Store('My', 'LocalMachine')
        $store.Open('ReadOnly')
        try {
            $found = $store.Certificates | Where-Object { $_.Thumbprint -eq $certThumbprint } | Select-Object -First 1
            if (-not $found) { throw 'the certificate is not in LocalMachine\My after accept' }
            if (-not $found.HasPrivateKey) { throw 'the certificate was installed but has no private key attached' }
            $leaf = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($found)
        } finally {
            $store.Close()
        }

        Write-Step 3 'Building the PFX...'
        $chain = Get-ChainCertificate -PemPath $ChainPath -Leaf $leaf

        $bundle = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
        [void] $bundle.Add($leaf)
        foreach ($c in $chain) { if ($c.Thumbprint -ne $leaf.Thumbprint) { [void] $bundle.Add($c) } }

        try {
            $bytes = $bundle.Export('Pkcs12', $pfxPlain)
        } catch {
            throw @"
Export failed: $($_.Exception.Message)

This almost always means the private key was created non-exportable. The key
cannot be extracted after the fact. Either:
  - keep using the certificate on this machine without a PFX (it is installed
    and working now), or
  - generate a new CSR with an exportable key and have it signed again.
"@
        }
        if (-not $bytes -or $bytes.Length -eq 0) { throw 'PFX export returned no data' }
        [System.IO.File]::WriteAllBytes($PfxPath, $bytes)
    }

    'AlreadyInstalled' {
        Write-Step 1 'Exporting the installed certificate...'
        $store = New-Object System.Security.Cryptography.X509Certificates.X509Store('My', 'LocalMachine')
        $store.Open('ReadOnly')
        try {
            $candidates = @($store.Certificates | Where-Object { $_.Thumbprint -eq $certThumbprint })
            if ($Thumbprint) {
                $candidates = @($candidates | Where-Object { $_.Thumbprint -eq $Thumbprint.ToUpper().Replace(' ', '') })
            }
            if ($candidates.Count -eq 0) { throw 'the certificate is no longer in LocalMachine\My' }
            $leaf = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($candidates[0])
        } finally {
            $store.Close()
        }

        $chain = Get-ChainCertificate -PemPath $ChainPath -Leaf $leaf

        $bundle = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
        [void] $bundle.Add($leaf)
        foreach ($c in $chain) { if ($c.Thumbprint -ne $leaf.Thumbprint) { [void] $bundle.Add($c) } }

        try {
            $bytes = $bundle.Export('Pkcs12', $pfxPlain)
        } catch {
            throw "Export failed: $($_.Exception.Message). The private key is most likely non-exportable; it cannot be extracted after the fact."
        }
        [System.IO.File]::WriteAllBytes($PfxPath, $bytes)
    }

    'OpenSsl' {
        Write-Step 1 'Locating openssl.exe...'

        $openssl = $null
        if ($OpenSslPath) {
            if (-not (Test-Path -LiteralPath $OpenSslPath -PathType Leaf)) { throw "openssl.exe not found at: $OpenSslPath" }
            $openssl = (Resolve-Path -LiteralPath $OpenSslPath).ProviderPath
        } else {
            try { $openssl = (Get-Command 'openssl.exe' -ErrorAction Stop).Source } catch { }
            if (-not $openssl) {
                foreach ($candidate in @(
                    "$env:ProgramFiles\OpenSSL-Win64\bin\openssl.exe",
                    "$env:ProgramFiles\OpenSSL\bin\openssl.exe",
                    "${env:ProgramFiles(x86)}\OpenSSL-Win32\bin\openssl.exe",
                    "$env:ProgramFiles\Git\usr\bin\openssl.exe",
                    "$env:ProgramFiles\Git\mingw64\bin\openssl.exe")) {
                    if (Test-Path -LiteralPath $candidate) { $openssl = $candidate; break }
                }
            }
        }

        if (-not $openssl) {
            $chainArg = ''
            if ($ChainPath) { $chainArg = " -certfile `"$ChainPath`"" }
            Write-Host ''
            Write-Host 'openssl.exe was not found on this machine.' -ForegroundColor Red
            Write-Host 'Combining a PEM key with a certificate needs it. Either install OpenSSL' -ForegroundColor DarkYellow
            Write-Host '(or use the Git for Windows copy), or run this on any Linux box:' -ForegroundColor DarkYellow
            Write-Host ''
            Write-Host ("  openssl pkcs12 -export -inkey `"{0}`" -in `"{1}`"{2} -out `"{3}`"" -f `
                $KeyPath, $CertificatePath, $chainArg, $PfxPath) -ForegroundColor White
            Write-Host ''
            throw 'OpenSSL is required for this route.'
        }
        Write-Host ("Using: {0}" -f $openssl)

        Write-Step 2 'Checking the key matches the certificate...'
        # A mismatched key is the most common failure here, and openssl's own
        # error for it is obscure, so compare the public moduli up front.
        $certMod = (& $openssl x509 -noout -modulus -in "$CertificatePath" 2>&1) -join ''
        $keyMod  = (& $openssl rsa  -noout -modulus -in "$KeyPath" 2>&1) -join ''

        if ($certMod -match 'Modulus=([0-9A-Fa-f]+)' ) { $certMod = $matches[1] } else { $certMod = $null }
        if ($keyMod  -match 'Modulus=([0-9A-Fa-f]+)' ) { $keyMod  = $matches[1] } else { $keyMod  = $null }

        if ($certMod -and $keyMod) {
            if ($certMod -ne $keyMod) {
                throw @"
The private key does not match this certificate.

They are from different key pairs, so no PFX can be made from them. Find the
key that was generated alongside the CSR you sent to the CA, or generate a new
CSR and have it signed again.
"@
            }
            Write-Host 'Key and certificate match.' -ForegroundColor Green
        } else {
            Write-Warning 'Could not compare the key and certificate (an encrypted or non-RSA key does this). Continuing.'
        }

        Write-Step 3 'Building the PFX...'
        # The password goes through the environment, not the command line:
        # anything on the command line is visible to every process on the box.
        $env:CONVERT_PFX_PASS = $pfxPlain
        $opensslArgs = @('pkcs12', '-export', '-inkey', $KeyPath, '-in', $CertificatePath,
                         '-out', $PfxPath, '-passout', 'env:CONVERT_PFX_PASS')
        if ($ChainPath) { $opensslArgs += @('-certfile', $ChainPath) }

        try {
            $out = & $openssl @opensslArgs 2>&1
        } finally {
            Remove-Item Env:\CONVERT_PFX_PASS -ErrorAction SilentlyContinue
        }

        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $PfxPath)) {
            $outText = (($out | Where-Object { $_ -match '\S' }) -join ' | ')
            if ($outText -match 'bad decrypt|wrong|passphrase') {
                throw "OpenSSL could not read the private key. If it is passphrase-protected, decrypt it first: openssl rsa -in `"$KeyPath`" -out key-decrypted.key  ($outText)"
            }
            throw ("openssl failed: " + $outText)
        }
    }
}

# ---------------------------------------------------------------- verify

$pfxPlainForCheck = $pfxPlain
$pfxPlain = $null

Write-Step 4 'Verifying the PFX...'

$check = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
try {
    $check.Import($PfxPath, $pfxPlainForCheck,
        [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::EphemeralKeySet)
} catch {
    # EphemeralKeySet does not exist before .NET 4.7.2; fall back.
    $check = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
    $check.Import($PfxPath, $pfxPlainForCheck,
        [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::DefaultKeySet)
}

$withKey = @($check | Where-Object { $_.HasPrivateKey })
$pfxPlainForCheck = $null
[System.GC]::Collect()

$size = (Get-Item -LiteralPath $PfxPath).Length

Write-Host ''
Write-Host ("PFX written   : {0}" -f $PfxPath)
Write-Host ("Size          : {0:N0} bytes" -f $size)
Write-Host ("Certificates  : {0} ({1} with a private key)" -f $check.Count, $withKey.Count)
foreach ($c in $check) {
    $keyMark = '      '
    if ($c.HasPrivateKey) { $keyMark = ' +key ' }
    Write-Host ("   {0} {1}" -f $keyMark, $c.Subject)
}

if ($withKey.Count -eq 0) {
    throw 'The PFX was written but contains no private key. Something is wrong; do not ship this file.'
}
if ($check.Count -eq 1) {
    Write-Warning 'The PFX holds the certificate alone, with no chain. It will work, but clients may'
    Write-Warning 'report an untrusted chain. Re-run with -ChainPath ca-chain.pem from the CA zip.'
}

Write-Host ''
Write-Host '[PASS] PFX built and verified.' -ForegroundColor Green
Write-Host ''
Write-Host 'This file contains the private key. Treat it as a secret: send it over a' -ForegroundColor Cyan
Write-Host 'trusted channel and delete the copy once installed.' -ForegroundColor Cyan

exit 0
