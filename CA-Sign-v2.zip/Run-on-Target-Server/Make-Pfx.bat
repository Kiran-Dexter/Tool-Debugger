@echo off
setlocal EnableExtensions

echo ==========================================
echo     Build a PFX from a signed certificate
echo     Run this on the machine that made the
echo     CSR - NOT on the CA
echo ==========================================
echo.

net session >nul 2>&1
if errorlevel 1 (
    echo [FAIL] Not running elevated.
    echo        Right-click this BAT and choose "Run as administrator".
    echo.
    pause
    exit /b 3
)

where powershell.exe >nul 2>&1
if errorlevel 1 (
    echo [FAIL] powershell.exe not found in PATH.
    echo.
    pause
    exit /b 3
)

set "SCRIPT=%~dp0Convert-ToPfx.ps1"
if not exist "%SCRIPT%" (
    echo [FAIL] Convert-ToPfx.ps1 must sit next to this BAT.
    echo        Expected: %SCRIPT%
    echo.
    pause
    exit /b 3
)

rem Drag the signed .cer onto this BAT, or pass it as the first argument.
set "CERT=%~1"

if defined CERT (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -CertificatePath "%CERT%" %2 %3 %4 %5 %6
) else (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" %*
)
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo ==========================================
    echo SUCCESS - PFX built and verified
    echo ==========================================
) else (
    echo ==========================================
    echo FAILED - exit code %RC%
    echo Read the message above; it names the cause.
    echo ==========================================
)

echo.
pause
exit /b %RC%
