@echo off
setlocal EnableExtensions

echo ==========================================
echo     RDP TLS Certificate Installer
echo     Windows Server 2012 - 2025
echo ==========================================
echo.

rem ---------- elevation ----------
net session >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Run this BAT as Administrator.
    echo.
    pause
    exit /b 1
)

rem ---------- PowerShell present ----------
where powershell.exe >nul 2>&1
if errorlevel 1 (
    echo [ERROR] powershell.exe not found in PATH.
    echo.
    pause
    exit /b 1
)

rem ---------- worker script ----------
set "SCRIPT=%~dp0Install-RdpCertificate.ps1"
if not exist "%SCRIPT%" (
    echo [ERROR] Install-RdpCertificate.ps1 must sit next to this BAT.
    echo         Expected: %SCRIPT%
    echo.
    pause
    exit /b 1
)

rem ---------- PFX path ----------
rem %~1 has quotes stripped already; typed input does not.
set "PFXFILE=%~1"
if not defined PFXFILE set /p "PFXFILE=Enter full PFX path: "
if defined PFXFILE set PFXFILE=%PFXFILE:"=%

if not defined PFXFILE (
    echo [ERROR] No PFX path supplied.
    echo.
    pause
    exit /b 1
)

if not exist "%PFXFILE%" (
    echo [ERROR] File not found:
    echo         %PFXFILE%
    echo.
    pause
    exit /b 1
)

rem ---------- optional switches ----------
rem Pass through anything after the path, e.g.:
rem   Install-RdpCertificate.bat C:\certs\rdp.pfx -RestartService
set "EXTRA=%2 %3 %4 %5"

echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -PfxPath "%PFXFILE%" %EXTRA%
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
    echo.
    echo ==========================================
    echo [FAILED] RDP TLS configuration failed. Exit code %RC%.
    echo ==========================================
    echo.
    pause
    exit /b %RC%
)

echo.
echo ==========================================
echo SUCCESS - certificate bound to RDP with TLS
echo ==========================================
echo.
pause
exit /b 0
