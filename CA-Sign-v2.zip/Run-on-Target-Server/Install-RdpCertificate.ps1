<#
.SYNOPSIS
    Imports a PFX certificate and binds it to the RDP-Tcp listener with TLS + NLA.

.DESCRIPTION
    Compatible with Windows Server 2012, 2012 R2, 2016, 2019, 2022 and 2025
    (PowerShell 3.0 and later, .NET 4.0 and later).

    Deliberately avoids version-specific cmdlets and properties:
      * imports with System.Security.Cryptography.X509Certificates rather than
        Import-PfxCertificate (whose parameters differ across OS versions)
      * finds the private key container with certutil rather than
        RSACertificateExtensions (.NET 4.6+ only)
      * grants key access with icacls and a well-known SID rather than
        localized account names
      * binds via WMI with a direct registry fallback

    All certificate quality checks are warnings by default so a valid PFX always
    binds. Use -Strict to turn them into failures.

.PARAMETER PfxPath
    Full path to the .pfx file. Prompted for if omitted.

.PARAMETER Password
    PFX password as a SecureString. Prompted for if omitted.

.PARAMETER Exportable
    Mark the imported private key exportable. Off by default.

.PARAMETER RestartService
    Restart TermService after binding. Not needed for new connections and will
    disconnect every current RDP session, including yours.

.PARAMETER Strict
    Treat certificate validation warnings as errors.

.EXAMPLE
    .\Install-RdpCertificate.ps1 -PfxPath C:\certs\rdp.pfx
#>
[CmdletBinding()]
param(
    [string]       $PfxPath,
    [System.Security.SecureString] $Password,
    [switch]       $Exportable,
    [switch]       $RestartService,
    [switch]       $Strict
)

$ErrorActionPreference = 'Stop'
$script:Warnings = New-Object System.Collections.ArrayList

function Write-Step {
    param([int] $Number, [string] $Message)
    Write-Host ''
    Write-Host ("[{0}] {1}" -f $Number, $Message) -ForegroundColor Yellow
}

function Add-Problem {
    param([string] $Message)
    [void] $script:Warnings.Add($Message)
    Write-Warning $Message
}

function ConvertFrom-SecureStringPlain {
    param([System.Security.SecureString] $Secure)
    $ptr = [System.Runtime.InteropServices.Marshal]::SecureStringToGlobalAllocUnicode($Secure)
    try   { [System.Runtime.InteropServices.Marshal]::PtrToStringUni($ptr) }
    finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeGlobalAllocUnicode($ptr) }
}

# ---------------------------------------------------------------- preconditions

$identity  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'This script must run elevated (Run as Administrator).'
}

$os = Get-WmiObject -Class Win32_OperatingSystem
Write-Host ("Host           : {0}" -f $env:COMPUTERNAME)
Write-Host ("OS             : {0} (build {1})" -f $os.Caption.Trim(), $os.BuildNumber)
Write-Host ("PowerShell     : {0}" -f $PSVersionTable.PSVersion.ToString())

if ($PSVersionTable.PSVersion.Major -lt 3) {
    throw "PowerShell 3.0 or later is required. Found $($PSVersionTable.PSVersion)."
}

if (-not $PfxPath) { $PfxPath = Read-Host 'Enter full PFX path' }
$PfxPath = $PfxPath.Trim().Trim('"').Trim("'")
if (-not $PfxPath) { throw 'No PFX path supplied.' }
if (-not (Test-Path -LiteralPath $PfxPath -PathType Leaf)) { throw "File not found: $PfxPath" }
$PfxPath = (Resolve-Path -LiteralPath $PfxPath).ProviderPath
Write-Host ("PFX File       : {0}" -f $PfxPath)

if (-not $Password) { $Password = Read-Host 'Enter PFX password' -AsSecureString }

# ------------------------------------------------------------------- 1. import

Write-Step 1 'Importing certificate into LocalMachine\My...'

$flags = [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::MachineKeySet -bor `
         [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::PersistKeySet
if ($Exportable) {
    $flags = $flags -bor [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable
}

$collection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
$plain = ConvertFrom-SecureStringPlain $Password
try {
    try {
        $collection.Import($PfxPath, $plain, $flags)
    } catch {
        throw "Could not read the PFX. Wrong password, or the file is not a valid PKCS#12: $($_.Exception.Message)"
    }
} finally {
    $plain = $null
    [System.GC]::Collect()
}

if ($collection.Count -eq 0) { throw 'The PFX contained no certificates.' }

# A PFX routinely bundles intermediates. The leaf is the newest cert holding a key.
$cert = $null
foreach ($c in $collection) {
    if ($c.HasPrivateKey) {
        if (-not $cert -or $c.NotAfter -gt $cert.NotAfter) { $cert = $c }
    }
}
if (-not $cert) { throw 'No certificate in the PFX has a private key. RDP cannot use it.' }

$myStore = New-Object System.Security.Cryptography.X509Certificates.X509Store('My', 'LocalMachine')
$myStore.Open('ReadWrite')
try   { $myStore.Add($cert) }
finally { $myStore.Close() }

$thumbprint = $cert.Thumbprint.ToUpper()

Write-Host ("Subject        : {0}" -f $cert.Subject)
Write-Host ("Issuer         : {0}" -f $cert.Issuer)
Write-Host ("Thumbprint     : {0}" -f $thumbprint)
Write-Host ("Valid from     : {0}" -f $cert.NotBefore)
Write-Host ("Expires        : {0}" -f $cert.NotAfter)

# Park chain certificates where clients can find them.
foreach ($c in $collection) {
    if ($c.Thumbprint -eq $cert.Thumbprint) { continue }
    if ($c.HasPrivateKey) { continue }
    $storeName = if ($c.Subject -eq $c.Issuer) { 'Root' } else { 'CA' }
    $chainStore = New-Object System.Security.Cryptography.X509Certificates.X509Store($storeName, 'LocalMachine')
    $chainStore.Open('ReadWrite')
    try {
        $chainStore.Add($c)
        Write-Host ("Chain cert -> LocalMachine\{0} : {1}" -f $storeName, $c.Subject)
    } catch {
        Write-Warning ("Could not add chain cert to {0}: {1}" -f $storeName, $_.Exception.Message)
    } finally {
        $chainStore.Close()
    }
}

# ----------------------------------------------------------------- 2. validate

Write-Step 2 'Validating certificate...'

$now = Get-Date
if ($cert.NotAfter  -lt $now) { Add-Problem ("Certificate expired on {0}." -f $cert.NotAfter) }
if ($cert.NotBefore -gt $now) { Add-Problem ("Certificate is not valid until {0}." -f $cert.NotBefore) }

# EKU via the raw extension, not the PS-added EnhancedKeyUsageList property.
$ekuExt = $null
foreach ($ext in $cert.Extensions) {
    if ($ext.Oid.Value -eq '2.5.29.37') {
        $ekuExt = [System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension] $ext
    }
}
if ($ekuExt) {
    $hasServerAuth = $false
    foreach ($oid in $ekuExt.EnhancedKeyUsages) {
        if ($oid.Value -eq '1.3.6.1.5.5.7.3.1') { $hasServerAuth = $true }
    }
    if (-not $hasServerAuth) {
        Add-Problem 'Certificate lacks the Server Authentication EKU (1.3.6.1.5.5.7.3.1). Clients will reject it.'
    }
}

# Host name check, parsed from the SAN extension.
try   { $fqdn = [System.Net.Dns]::GetHostEntry($env:COMPUTERNAME).HostName }
catch { $fqdn = $env:COMPUTERNAME }

$sanNames = @()
foreach ($ext in $cert.Extensions) {
    if ($ext.Oid.Value -eq '2.5.29.17') {
        foreach ($line in ($ext.Format($true) -split "`r?`n")) {
            if ($line -match 'DNS Name=([^,\s]+)') { $sanNames += $matches[1].Trim() }
        }
    }
}
if ($sanNames.Count -eq 0) {
    Add-Problem 'Certificate has no DNS Subject Alternative Names. Current clients require them.'
} else {
    $nameMatch = $false
    foreach ($n in $sanNames) {
        if ($n -eq $fqdn) { $nameMatch = $true }
        elseif ($n.StartsWith('*.') -and $fqdn -like $n) { $nameMatch = $true }
    }
    if (-not $nameMatch) {
        Add-Problem ("No SAN matches this host ({0}). Certificate covers: {1}" -f $fqdn, ($sanNames -join ', '))
    } else {
        Write-Host ("Name match     : {0}" -f $fqdn)
    }
}

# Chain build, revocation off so an offline CRL endpoint is not treated as failure.
$chain = New-Object System.Security.Cryptography.X509Certificates.X509Chain
$chain.ChainPolicy.RevocationMode = 'NoCheck'
if (-not $chain.Build($cert)) {
    $statusText = @()
    foreach ($s in $chain.ChainStatus) { $statusText += $s.Status.ToString() }
    Add-Problem ("Chain does not validate on this host: {0}. Clients that do not trust the issuer will warn." -f ($statusText -join ', '))
} else {
    Write-Host 'Chain          : builds successfully'
}

if ($script:Warnings.Count -eq 0) {
    Write-Host 'Certificate is suitable for RDP.' -ForegroundColor Green
} elseif ($Strict) {
    throw 'Validation failed and -Strict was specified. Nothing was bound.'
}

# ------------------------------------------------- 3. private key permissions

Write-Step 3 'Granting the Remote Desktop service read access to the private key...'

# certutil reports the container name identically on 2012 through 2025, unlike
# the .NET key-access APIs, which moved between framework versions.
$containerName = $null
$certutilOut = & certutil.exe -store My $thumbprint 2>&1
foreach ($line in $certutilOut) {
    if ($line -match 'Unique container name:\s*(\S+)') { $containerName = $matches[1]; break }
}

$keyFile = $null
if ($containerName) {
    $candidates = @(
        (Join-Path $env:ProgramData "Microsoft\Crypto\RSA\MachineKeys\$containerName"),
        (Join-Path $env:ProgramData "Microsoft\Crypto\Keys\$containerName"),
        (Join-Path $env:ProgramData "Microsoft\Crypto\SystemKeys\$containerName"),
        (Join-Path $env:ProgramData "Microsoft\Crypto\PCPKSP\$containerName")
    )
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) { $keyFile = $candidate; break }
    }
}

if ($keyFile) {
    # *S-1-5-20 is NETWORK SERVICE. Using the SID avoids breaking on non-English builds.
    $icaclsOut = & icacls.exe "$keyFile" /grant "*S-1-5-20:(R)" 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host ("Key ACL updated: {0}" -f $keyFile)
    } else {
        Add-Problem ("icacls failed on the private key: {0}" -f ($icaclsOut -join ' '))
    }
} else {
    Add-Problem 'Could not locate the private key file. If RDP keeps presenting a self-signed certificate, open certlm.msc, right-click the certificate, All Tasks > Manage Private Keys, and give NETWORK SERVICE read access.'
}

# ----------------------------------------------------------- 4. bind to RDP-Tcp

Write-Step 4 'Binding certificate to the RDP-Tcp listener...'

$regPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp'
if (-not (Test-Path $regPath)) {
    throw 'RDP-Tcp listener registry key not found. Is Remote Desktop installed on this host?'
}

$bound = $false

# The TerminalServices namespace requires packet privacy on some builds, so try
# that first and fall back.
$tsSetting = $null
foreach ($auth in @('PacketPrivacy', 'Default')) {
    try {
        $tsSetting = Get-WmiObject -Namespace 'root\CIMV2\TerminalServices' `
                                   -Class Win32_TSGeneralSetting `
                                   -Filter "TerminalName='RDP-tcp'" `
                                   -Authentication $auth -ErrorAction Stop
        if ($tsSetting) { break }
    } catch {
        $tsSetting = $null
    }
}

if ($tsSetting) {
    if ($tsSetting.SSLCertificateSHA1Hash) {
        Write-Host ("Previous hash  : {0}" -f $tsSetting.SSLCertificateSHA1Hash)
    }
    try {
        $tsSetting.SSLCertificateSHA1Hash = $thumbprint
        [void] $tsSetting.Put()
        $bound = $true
        Write-Host 'Bound via WMI.'
    } catch {
        Write-Warning ("WMI binding failed, falling back to the registry: {0}" -f $_.Exception.Message)
    }
}

if (-not $bound) {
    # SSLCertificateSHA1Hash is a REG_BINARY of the 20-byte thumbprint.
    $bytes = New-Object byte[] 20
    for ($i = 0; $i -lt 20; $i++) {
        $bytes[$i] = [Convert]::ToByte($thumbprint.Substring($i * 2, 2), 16)
    }
    Set-ItemProperty -Path $regPath -Name 'SSLCertificateSHA1Hash' -Value $bytes -Type Binary
    $bound = $true
    Write-Host 'Bound via registry.'
}

# --------------------------------------------------------------- 5. TLS + NLA

Write-Step 5 'Enabling TLS (SecurityLayer=2) and NLA (UserAuthentication=1)...'

Set-ItemProperty -Path $regPath -Name 'SecurityLayer'      -Value 2 -Type DWord
Set-ItemProperty -Path $regPath -Name 'UserAuthentication' -Value 1 -Type DWord
Set-ItemProperty -Path $regPath -Name 'MinEncryptionLevel' -Value 3 -Type DWord

# ----------------------------------------------------------------- 6. verify

Write-Step 6 'Verifying...'

$regHash = $null
try {
    $raw = (Get-ItemProperty -Path $regPath -Name 'SSLCertificateSHA1Hash').SSLCertificateSHA1Hash
    if ($raw) {
        $sb = New-Object System.Text.StringBuilder
        foreach ($b in $raw) { [void] $sb.Append($b.ToString('X2')) }
        $regHash = $sb.ToString()
    }
} catch { }

$secLayer = (Get-ItemProperty -Path $regPath -Name 'SecurityLayer').SecurityLayer
$nla      = (Get-ItemProperty -Path $regPath -Name 'UserAuthentication').UserAuthentication

Write-Host ''
Write-Host ("Expected hash  : {0}" -f $thumbprint)
Write-Host ("Bound hash     : {0}" -f $regHash)
Write-Host ("SecurityLayer  : {0}  (2 = TLS)" -f $secLayer)
Write-Host ("NLA            : {0}  (1 = required)" -f $nla)

if ($regHash -ne $thumbprint) { throw 'Certificate binding did not take effect.' }
if ($secLayer -ne 2)          { throw 'SecurityLayer is not set to TLS.' }
if ($nla      -ne 1)          { throw 'NLA was not enabled.' }

Write-Host ''
Write-Host '[PASS] Certificate bound to RDP-Tcp with TLS and NLA.' -ForegroundColor Green
Write-Host 'New connections use it immediately. No service restart is required.'

if ($script:Warnings.Count -gt 0) {
    Write-Host ''
    Write-Host ("Completed with {0} warning(s):" -f $script:Warnings.Count) -ForegroundColor DarkYellow
    foreach ($w in $script:Warnings) { Write-Host ("  - {0}" -f $w) -ForegroundColor DarkYellow }
}

# -------------------------------------------------------- 7. optional restart

if ($RestartService) {
    Write-Step 7 'Restarting Remote Desktop Services...'
    if ($env:SESSIONNAME -and $env:SESSIONNAME -like 'RDP-Tcp*') {
        Write-Warning 'You are connected over RDP. This will drop your session.'
    }
    try {
        Restart-Service -Name TermService -Force
        Write-Host 'TermService restarted.' -ForegroundColor Green
    } catch {
        Write-Warning ("TermService would not restart: {0}" -f $_.Exception.Message)
        Write-Warning 'This is common and harmless. The certificate is already live for new connections.'
    }
}

Write-Host ''
Write-Host 'Check from a client:' -ForegroundColor Cyan
Write-Host ("  openssl s_client -connect {0}:3389 -starttls rdp" -f $fqdn) -ForegroundColor Cyan

exit 0
